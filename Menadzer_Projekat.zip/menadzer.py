import json
import os
from datetime import datetime

PODACI_FAJL = "klijenti_podaci.json"
SCHEDULE_FAJL = "schedule_podaci.json"
OUTREACH_FAJL = "outreach_podaci.json"

class MenazerKlijenata:
    def __init__(self):
        self.klijenti = self.ucitaj_podatke()
        self.schedule_data = self.ucitaj_schedule()
        self.outreach_data = self.ucitaj_outreach()
    
    def ucitaj_podatke(self):
        if os.path.exists(PODACI_FAJL):
            with open(PODACI_FAJL, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def sacuvaj_podatke(self):
        with open(PODACI_FAJL, 'w', encoding='utf-8') as f:
            json.dump(self.klijenti, f, ensure_ascii=False, indent=2)
        print("Podaci su uspesno sacuvani!")
    
    def dodaj_klijenta(self, ime, prezime, email, telefon):
        id_klijenta = str(len(self.klijenti) + 1)
        self.klijenti[id_klijenta] = {
            "ime": ime,
            "prezime": prezime,
            "email": email,
            "telefon": telefon,
            "paketi": [],
            "beleske": [],
            "kreiran": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.sacuvaj_podatke()
        print(f"Klijent {ime} {prezime} je dodat! (ID: {id_klijenta})")
        return id_klijenta
    
    def dodeli_paket(self, id_klijenta, naziv_paketa, cena, datum_pocetka):
        """Dodeljuje paket/proizvod klijentu i vraća True/False za uspeh"""
        try:
            if id_klijenta not in self.klijenti:
                print("Klijent sa tim ID-om nije pronadjen!")
                return False
            
            # Normalizuj cenu u string (čuvamo kako je uneto)
            cena_str = str(cena).strip()
            
            paket = {
                "naziv": naziv_paketa,
                "cena": cena_str,
                "datum_pocetka": datum_pocetka,
                "datum_dodele": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            self.klijenti[id_klijenta]["paketi"].append(paket)
            self.sacuvaj_podatke()
            print(f"Paket '{naziv_paketa}' je dodeljen klijentu!")
            return True
        except Exception as e:
            print(f"Greška pri dodeli paketa: {e}")
            return False

    def obrisi_klijenta(self, id_klijenta):
        """Briše klijenta i vraća True/False za uspeh"""
        if id_klijenta in self.klijenti:
            try:
                del self.klijenti[id_klijenta]
                self.sacuvaj_podatke()
                print(f"Klijent {id_klijenta} je obrisan!")
                return True
            except Exception as e:
                print(f"Greška pri brisanju klijenta: {e}")
                return False
        print("Klijent sa tim ID-om nije pronadjen!")
        return False
    
    def dodaj_belesku(self, id_klijenta, tekst_beleske):
        """Dodaje belešku klijentu i vraća True/False za uspeh"""
        if id_klijenta not in self.klijenti:
            print("Klijent sa tim ID-om nije pronadjen!")
            return False
        try:
            beleska = {
                "tekst": tekst_beleske,
                "datum": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            self.klijenti[id_klijenta]["beleske"].append(beleska)
            self.sacuvaj_podatke()
            print("Beleška je dodata!")
            return True
        except Exception as e:
            print(f"Greška pri dodavanju beleške: {e}")
            return False

    # Ostavimo stari, pogrešno imenovan metod kao alias radi kompatibilnosti
    def dodaj_beleszku(self, id_klijenta, tekst_beleske):
        return self.dodaj_belesku(id_klijenta, tekst_beleske)
    
    def prikazi_sve_klijente(self):
        if not self.klijenti:
            print("Nema registrovanih klijenata.")
            return
        
        print("\n" + "="*60)
        print("LISTA KLIJENATA")
        print("="*60)
        
        for id_klijenta, klijent in self.klijenti.items():
            print(f"\nID: {id_klijenta}")
            print(f"Ime i prezime: {klijent['ime']} {klijent['prezime']}")
            print(f"Email: {klijent['email']}")
            print(f"Telefon: {klijent['telefon']}")
            print(f"Broj paketa: {len(klijent['paketi'])}")
            print(f"Broj beleski: {len(klijent['beleske'])}")
    
    def prikazi_detalje_klijenta(self, id_klijenta):
        if id_klijenta not in self.klijenti:
            print("Klijent sa tim ID-om nije pronadjen!")
            return
        
        klijent = self.klijenti[id_klijenta]
        
        print("\n" + "="*60)
        print(f"DETALJI KLIJENTA - {klijent['ime']} {klijent['prezime']}")
        print("="*60)
        
        print(f"Email: {klijent['email']}")
        print(f"Telefon: {klijent['telefon']}")
        
        print("\nPAKETI:")
        if klijent['paketi']:
            for i, paket in enumerate(klijent['paketi'], 1):
                print(f"  {i}. {paket['naziv']} - {paket['cena']} din (Od: {paket['datum_pocetka']})")
        else:
            print("  Nema dodeljenih paketa.")
        
        print("\nBELESKE:")
        if klijent['beleske']:
            for i, beleszka in enumerate(klijent['beleske'], 1):
                print(f"  {i}. [{beleszka['datum']}] {beleszka['tekst']}")
        else:
            print("  Nema beleski.")

    def izmeni_belesku(self, id_klijenta, indeks, novi_tekst):
        """Menja tekst beleške po indeksu; vraća True/False"""
        if id_klijenta not in self.klijenti:
            return False
        try:
            beleške = self.klijenti[id_klijenta].get('beleske', [])
            if indeks < 0 or indeks >= len(beleške):
                return False
            beleške[indeks]['tekst'] = novi_tekst
            # Osveži datum izmene (opciono: zadržati originalni)
            beleške[indeks]['datum'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.sacuvaj_podatke()
            return True
        except Exception:
            return False

    def obrisi_belesku(self, id_klijenta, indeks):
        """Briše belešku po indeksu; vraća True/False"""
        if id_klijenta not in self.klijenti:
            return False
        try:
            beleške = self.klijenti[id_klijenta].get('beleske', [])
            if indeks < 0 or indeks >= len(beleške):
                return False
            del beleške[indeks]
            self.sacuvaj_podatke()
            return True
        except Exception:
            return False
    
    def ucitaj_schedule(self):
        """Učitava schedule podatke iz JSON fajla"""
        if os.path.exists(SCHEDULE_FAJL):
            with open(SCHEDULE_FAJL, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def sacuvaj_schedule(self):
        """Čuva schedule podatke u JSON fajl"""
        with open(SCHEDULE_FAJL, 'w', encoding='utf-8') as f:
            json.dump(self.schedule_data, f, ensure_ascii=False, indent=2)
    
    def dodaj_schedule_zadatak(self, data):
        """Dodaje novi zadatak u schedule"""
        task_id = str(len(self.schedule_data) + 1)
        self.schedule_data[task_id] = {
            'datum': data['datum'],
            'dan': data['dan'],
            'klijent': data['klijent'],
            'zadatak': data['zadatak'],
            'status': data['status']
        }
        self.sacuvaj_schedule()
        return task_id
    
    def ucitaj_outreach(self):
        """Učitava outreach podatke iz JSON fajla"""
        if os.path.exists(OUTREACH_FAJL):
            with open(OUTREACH_FAJL, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}
    
    def sacuvaj_outreach(self):
        """Čuva outreach podatke u JSON fajl"""
        with open(OUTREACH_FAJL, 'w', encoding='utf-8') as f:
            json.dump(self.outreach_data, f, ensure_ascii=False, indent=2)
    
    def dodaj_outreach(self, data):
        """Dodaje novi outreach u sistem"""
        outreach_id = str(len(self.outreach_data) + 1)
        self.outreach_data[outreach_id] = {
            'datum': data['datum'],
            'klijent': data['klijent'],
            'email': data['email'],
            'status': data['status'],
            'odgovor': data.get('odgovor', False),
            'napomene': data.get('napomene', '')
        }
        self.sacuvaj_outreach()
        return outreach_id

def meni():
    menadzer = MenazerKlijenata()
    
    while True:
        print("\n" + "="*60)
        print("MENADZER KLIJENATA")
        print("="*60)
        print("1. Dodaj novog klijenta")
        print("2. Dodeli paket proizvoda")
        print("3. Dodaj belsku za klijenta")
        print("4. Prikazi sve klijente")
        print("5. Prikazi detalje klijenta")
        print("6. Izlaz")
        print("="*60)
        
        izbor = input("Odaberi opciju (1-6): ").strip()
        
        if izbor == "1":
            print("\n--- DODAVANJE NOVOG KLIJENTA ---")
            ime = input("Unesi ime: ").strip()
            prezime = input("Unesi prezime: ").strip()
            email = input("Unesi email: ").strip()
            telefon = input("Unesi telefon: ").strip()
            
            if ime and prezime and email:
                menadzer.dodaj_klijenta(ime, prezime, email, telefon)
            else:
                print("Molim unesi sve obavezne podatke!")
        
        elif izbor == "2":
            print("\n--- DODELJIVANJE PAKETA ---")
            menadzer.prikazi_sve_klijente()
            id_klijenta = input("\nUnesi ID klijenta: ").strip()
            
            if id_klijenta in menadzer.klijenti:
                naziv_paketa = input("Unesi naziv paketa: ").strip()
                cena = input("Unesi cenu (dinara): ").strip()
                datum_pocetka = input("Unesi datum pocetka (YYYY-MM-DD): ").strip()
                
                if naziv_paketa and cena:
                    menadzer.dodeli_paket(id_klijenta, naziv_paketa, cena, datum_pocetka)
                else:
                    print("Molim unesi sve obavezne podatke!")
            else:
                print("Klijent sa tim ID-om nije pronadjen!")
        
        elif izbor == "3":
            print("\n--- DODAVANJE BELESKE ---")
            menadzer.prikazi_sve_klijente()
            id_klijenta = input("\nUnesi ID klijenta: ").strip()
            
            if id_klijenta in menadzer.klijenti:
                tekst_beleske = input("Unesi belsku: ").strip()
                if tekst_beleske:
                    menadzer.dodaj_beleszku(id_klijenta, tekst_beleske)
                else:
                    print("Beliska ne moze biti prazna!")
            else:
                print("Klijent sa tim ID-om nije pronadjen!")
        
        elif izbor == "4":
            menadzer.prikazi_sve_klijente()
        
        elif izbor == "5":
            print("\n--- DETALJI KLIJENTA ---")
            menadzer.prikazi_sve_klijente()
            id_klijenta = input("\nUnesi ID klijenta: ").strip()
            menadzer.prikazi_detalje_klijenta(id_klijenta)
        
        elif izbor == "6":
            print("\nDo vidjenja!")
            break
        
        else:
            print("Nevalidna opcija! Molim odaberi broj od 1 do 6.")

if __name__ == "__main__":
    meni()
