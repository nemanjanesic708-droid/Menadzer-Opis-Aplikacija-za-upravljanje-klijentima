﻿
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import hashlib
import time
from menadzer import MenazerKlijenata

# Uvek koristi JSON fajl u istom folderu kao skripta
PODACI_FAJL = os.path.join(os.path.dirname(__file__), "klijenti_podaci.json")
KORISNICI_FAJL = os.path.join(os.path.dirname(__file__), "korisnici.json")

class UserManager:
    def __init__(self):
        self.korisnici = self.ucitaj_korisnike()
    
    def ucitaj_korisnike(self):
        if os.path.exists(KORISNICI_FAJL):
            try:
                with open(KORISNICI_FAJL, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def sacuvaj_korisnike(self):
        try:
            with open(KORISNICI_FAJL, 'w', encoding='utf-8') as f:
                json.dump(self.korisnici, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"Gre\u0161ka pri \u010duvanju korisnika: {e}")
            return False
    
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def registruj_korisnika(self, username, password):
        if username in self.korisnici:
            return False, "Korisni\u010dko ime ve\u0107 postoji!"
        
        self.korisnici[username] = {
            "password": self.hash_password(password),
            "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.sacuvaj_korisnike()
        return True, "Nalog uspe\u0161no kreiran!"
    
    def autentifikuj(self, username, password):
        if username not in self.korisnici:
            return False, "Korisnik ne postoji!"
        
        if self.korisnici[username]["password"] == self.hash_password(password):
            return True, "Uspe\u0161na prijava!"
        return False, "Pogre\u0161na lozinka!"


# MenazerKlijenata class is imported from menadzer.py

class GUIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Menad\u017eer Klijenata - Login")
        self.root.geometry("1200x700")
        self.root.configure(bg='#f5f6fa')
        
        self.user_manager = UserManager()
        self.menadzer = MenazerKlijenata()
        self.current_user = None
        self.inactivity_timeout = 15 * 60  # 15 minuta u sekundama
        self.last_activity = time.time()
        self.timer_running = False
        
        # Dark mode state
        self.dark_mode = False
        self.light_colors = {
            'bg': '#f5f6fa',
            'header': '#2c3e50',
            'text': '#2c3e50',
            'button_bg': '#f5f6fa',
            'section_bg': 'white',
            'fg': '#2c3e50',
            'fg_secondary': '#7f8c8d'
        }
        self.dark_colors = {
            'bg': '#1a1a2e',
            'header': '#16213e',
            'text': '#eaeaea',
            'button_bg': '#0f3460',
            'section_bg': '#16213e',
            'fg': '#eaeaea',
            'fg_secondary': '#95a5a6'
        }
        
        # Moderan stil
        self.setup_style()
        
        # Prikaži login ekran
        self.show_login_screen()
    
    def show_login_screen(self):
        """Prikazuje login ekran"""
        # Očisti prozor
        for widget in self.root.winfo_children():
            widget.destroy()
        
        self.root.title("Menadžer Klijenata - Prijava")
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Root background
        self.root.configure(bg=colors['bg'])
        
        # Dark mode toggle dugme u gornjem desnom uglu
        dark_toggle_btn = tk.Button(self.root, text="🌙" if not self.dark_mode else "☀️",
                                    command=lambda: self.toggle_dark_and_refresh_login(),
                                    font=('Segoe UI', 16), bg=colors['header'], fg='white',
                                    padx=15, pady=8, border=0, cursor='hand2', relief=tk.FLAT)
        dark_toggle_btn.place(relx=1.0, rely=0, anchor='ne', x=-20, y=20)
        
        # Centralni frame
        login_frame = tk.Frame(self.root, bg=colors['bg'])
        login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        # Logo/Naslov
        tk.Label(login_frame, text="👥 MENADŽER KLIJENATA", font=('Segoe UI', 28, 'bold'),
                bg=colors['bg'], fg=colors['fg']).pack(pady=(0, 10))
        
        tk.Label(login_frame, text="Prijavite se na svoj nalog", font=('Segoe UI', 12),
                bg=colors['bg'], fg=colors['fg_secondary']).pack(pady=(0, 30))
        
        # Login forma
        form_frame = tk.Frame(login_frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        form_frame.pack(padx=40, pady=20)
        
        tk.Label(form_frame, text="", bg=colors['section_bg']).pack(pady=10)  # Spacing
        
        tk.Label(form_frame, text="Korisničko ime:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        username_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, relief=tk.FLAT, bd=2)
        username_entry.pack(padx=30, pady=(5, 15), ipady=8)
        username_entry.focus()
        
        tk.Label(form_frame, text="Lozinka:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        password_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, show='●', relief=tk.FLAT, bd=2)
        password_entry.pack(padx=30, pady=(5, 20), ipady=8)
        
        def do_login():
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            if not username or not password:
                messagebox.showerror("Greška", "Unesite korisničko ime i lozinku!")
                return
            ok, poruka = self.user_manager.autentifikuj(username, password)
            if ok:
                self.current_user = username
                self.show_main_screen()
            else:
                messagebox.showerror("Greška", poruka)
            return

        def do_register():
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            if not username or not password:
                messagebox.showerror("Greška", "Unesite korisničko ime i lozinku!")
                return
            ok, poruka = self.user_manager.registruj_korisnika(username, password)
            if ok:
                messagebox.showinfo("Uspeh", poruka)
            else:
                messagebox.showerror("Greška", poruka)

        # Dugmad za prijavu/registraciju
        btns = tk.Frame(form_frame, bg=colors['section_bg'])
        btns.pack(fill=tk.X, padx=30, pady=(0, 20))
        login_btn = tk.Button(btns, text="✓ Prijavi se", command=do_login,
                              font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                              padx=20, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        login_btn.pack(side=tk.LEFT)
        self.add_button_hover(login_btn, '#27ae60', '#2ecc71')
        reg_btn = tk.Button(btns, text="＋ Kreiraj nalog", command=do_register,
                            font=('Segoe UI', 11), bg='#3498db', fg='white',
                            padx=20, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        reg_btn.pack(side=tk.LEFT, padx=(10, 0))
        self.add_button_hover(reg_btn, '#3498db', '#5dade2')

        # Enter za prijavu
        password_entry.bind('<Return>', lambda e: do_login())
    def setup_notebook(self):
        """Kreira notebook sa tabovima"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Notebook container sa marginama
        notebook_frame = tk.Frame(self.main_frame, bg=colors['bg'])
        notebook_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(5, 15))
        
        self.notebook = ttk.Notebook(notebook_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Tab 1: Outreach
        self.outreach_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.outreach_tab, text='  📧  Outreach  ')
        self.setup_outreach_tab()
        
        # Tab 2: Schedule
        self.schedule_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.schedule_tab, text='  🕐  Schedule  ')
        self.setup_schedule_tab()
        
        # Tab 3: Menadžment Klijenata (imenik)
        self.klijenti_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.klijenti_tab, text='  📋  Klijenti  ')
        self.setup_klijenti_tab()
        
        # Tab 4: Overview
        self.overview_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.overview_tab, text='  📊  Overview  ')
        self.setup_overview_tab()
    
    def start_inactivity_timer(self):
        """Pokreće tajmer za auto logout"""
        self.timer_running = True
        self.last_activity = time.time()
        self.check_inactivity()
    
    def check_inactivity(self):
        """Proverava neaktivnost i logout"""
        if not self.timer_running:
            return
        
        if time.time() - self.last_activity > self.inactivity_timeout:
            self.logout("Auto logout - neaktivnost")
            return
        
        self.root.after(1000, self.check_inactivity)  # Proveri svake sekunde
    
    def reset_timer(self, event=None):
        """Resetuje tajmer neaktivnosti"""
        self.last_activity = time.time()
    
    def logout(self, reason=""):
        """Odjavljuje korisnika"""
        self.timer_running = False
        if reason:
            messagebox.showinfo("Odjava", reason)
        self.current_user = None
        self.show_login_screen()
    
    def setup_style(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Modern color scheme
        style.configure('Title.TLabel', font=('Segoe UI', 24, 'bold'), background=colors['header'], foreground='white')
        style.configure('Header.TFrame', background=colors['header'])
        style.configure('Main.TFrame', background=colors['bg'])
        style.configure('TLabel', background=colors['bg'], foreground=colors['text'], font=('Segoe UI', 10))
        style.configure('TEntry', font=('Segoe UI', 10), padding=8)
        
        # NOTEBOOK/TAB STYLING - Veliki i lepši tabovi
        tab_bg = '#2c3e50' if not self.dark_mode else '#16213e'
        tab_fg = 'white'
        tab_selected_bg = '#3498db' if not self.dark_mode else '#1e5f8f'
        
        style.configure('TNotebook', background=colors['bg'], borderwidth=0, tabmargins=[2, 5, 2, 0])
        style.configure('TNotebook.Tab', 
                       font=('Segoe UI', 12, 'bold'),
                       padding=[25, 15],  # Veći padding za veće tabove
                       background=tab_bg,
                       foreground=tab_fg,
                       borderwidth=0)
        style.map('TNotebook.Tab',
                 background=[('selected', tab_selected_bg), ('active', '#34495e')],
                 foreground=[('selected', 'white'), ('active', 'white')],
                 expand=[('selected', [1, 1, 1, 0])])  # Selected tab je malo veći
        
        # Light mode Treeview
        style.configure('Treeview', font=('Segoe UI', 10), rowheight=35, background='white', 
                       foreground='#2c3e50', fieldbackground='white')
        style.configure('Treeview.Heading', font=('Segoe UI', 11, 'bold'), background='#1c2833', foreground='white')
        style.map('Treeview.Heading', background=[('active', '#17202a')])
        style.map('Treeview', background=[('selected', '#2874a6')], foreground=[('selected', 'white')])
        
        # Dark mode Treeview
        style.configure('Dark.Treeview', font=('Segoe UI', 10), rowheight=35, 
                       background='#0f3460', foreground='#eaeaea', fieldbackground='#0f3460')
        style.configure('Dark.Treeview.Heading', font=('Segoe UI', 11, 'bold'), 
                       background='#16213e', foreground='white')
        style.map('Dark.Treeview.Heading', background=[('active', '#1a2a4a')])
        style.map('Dark.Treeview', background=[('selected', '#1e5f8f')], foreground=[('selected', 'white')])
    
    def setup_header(self):
        self.header_frame = ttk.Frame(self.main_frame, style='Header.TFrame')
        self.header_frame.pack(fill=tk.X, padx=0, pady=0)
        
        title_frame = ttk.Frame(self.header_frame, style='Header.TFrame')
        title_frame.pack(fill=tk.X, padx=30, pady=20)
        
        title_label = ttk.Label(title_frame, text="👥 MENADŽER KLIJENATA", style='Title.TLabel', 
                               background='#2c3e50', foreground='white', font=('Segoe UI', 24, 'bold'))
        title_label.pack(side=tk.LEFT, anchor=tk.W)
        
        # Right side controls
        controls_frame = tk.Frame(title_frame, bg='#2c3e50')
        controls_frame.pack(side=tk.RIGHT, anchor=tk.E)
        
        # User label
        tk.Label(controls_frame, text=f"👤 {self.current_user}", font=('Segoe UI', 10, 'bold'),
                bg='#2c3e50', fg='#ecf0f1').pack(side=tk.LEFT, padx=(0, 15))
        
        # Settings button (gear icon)
        settings_btn = tk.Button(controls_frame, text="⚙️", command=self.show_settings,
                                font=('Segoe UI', 16), bg='#34495e', fg='white',
                                padx=10, pady=2, border=0, cursor='hand2', relief=tk.FLAT)
        settings_btn.pack(side=tk.LEFT, padx=(0, 10))
        self.add_button_hover(settings_btn, '#34495e', '#4a5f7f')
        
        # Logout button
        logout_btn = tk.Button(controls_frame, text="🚪 Odjava", command=lambda: self.logout(""),
                              font=('Segoe UI', 9, 'bold'), bg='#e74c3c', fg='white',
                              padx=12, pady=5, border=0, cursor='hand2', relief=tk.FLAT)
        logout_btn.pack(side=tk.LEFT)
        self.add_button_hover(logout_btn, '#e74c3c', '#ec7063')
    
    def setup_klijenti_tab(self):
        """Setup za Menadžment Klijenata tab - imenik za ponovnu saradnju"""
        content_frame = ttk.Frame(self.klijenti_tab, style='Main.TFrame')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Search bar
        colors = self.dark_colors if self.dark_mode else self.light_colors
        search_frame = tk.Frame(content_frame, bg=colors['bg'])
        search_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(search_frame, text="🔍", font=('Segoe UI', 16), bg=colors['bg'], fg=colors['fg']).pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.pretrazi_klijente())
        
        # Entry sa dinamičkim bojama
        search_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
        search_fg = colors['fg']
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, font=('Segoe UI', 11), 
                               relief=tk.FLAT, bd=2, width=40, bg=search_bg, fg=search_fg, 
                               insertbackground=search_fg)
        search_entry.pack(side=tk.LEFT, ipady=8, padx=(0, 15))
        
        tk.Label(search_frame, text="Pretraži po imenu, prezimenu, email-u ili telefonu", 
                font=('Segoe UI', 9), bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT)
        
        # Dugmići
        button_frame = ttk.Frame(content_frame, style='Main.TFrame')
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        # Ostavi samo dugme za dodavanje klijenta
        add_client_btn = tk.Button(button_frame, text="➕ Dodaj Klijenta", command=self.dodaj_klijenta_dijalog, 
                           font=('Segoe UI', 11, 'bold'), 
                           bg='#27ae60', fg='white', 
                           padx=20, pady=12, 
                           border=0, cursor='hand2',
                           relief=tk.FLAT,
                           activebackground=self.darker_color('#27ae60'),
                           activeforeground='white')
        add_client_btn.pack(side=tk.LEFT, padx=8)
        self.add_button_hover(add_client_btn, '#27ae60', self.lighter_color('#27ae60'))
        
        # Tabela
        tree_frame = ttk.Frame(content_frame, style='Main.TFrame')
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Koristi odgovarajući stil na osnovu dark_mode
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.tree = ttk.Treeview(tree_frame, 
                                columns=('ID', 'Ime', 'Prezime', 'Email', 'Telefon', 'Paketi', 'Beleške'),
                                height=20, yscrollcommand=scrollbar.set, style=tree_style)
        scrollbar.config(command=self.tree.yview)
        
        self.tree.column('#0', width=0, stretch=tk.NO)
        self.tree.column('ID', anchor=tk.CENTER, width=50)
        self.tree.column('Ime', anchor=tk.W, width=130)
        self.tree.column('Prezime', anchor=tk.W, width=130)
        self.tree.column('Email', anchor=tk.W, width=200)
        self.tree.column('Telefon', anchor=tk.W, width=120)
        self.tree.column('Paketi', anchor=tk.CENTER, width=80)
        self.tree.column('Beleške', anchor=tk.CENTER, width=80)
        
        for col in self.tree['columns']:
            self.tree.heading(col, text=col)
        
        self.tree.pack(fill=tk.BOTH, expand=True)

        # Dupli klik otvara detaljni prozor i desni klik meni
        self.tree.bind('<Double-Button-1>', lambda e: self.detaljni_pregled())
        self.tree.bind('<Button-3>', lambda e: self.klijenti_right_click_menu(e))
        
        # Dugme za pregled
        detail_btn = tk.Button(content_frame, text="👁️ Detaljni Pregled Klijenta", 
                              command=self.detaljni_pregled,
                              font=('Segoe UI', 10, 'bold'),
                              bg='#9b59b6', fg='white',
                              padx=15, pady=10,
                              border=0, cursor='hand2',
                              activebackground='#8e44ad')
        detail_btn.pack(side=tk.LEFT, padx=5)
        
        # Učitaj klijente
        self.ucitaj_klijente()

    def klijenti_right_click_menu(self, event):
        """Prikazuje context menu za Klijenti tabelu"""
        # Selektuj red pod mišem ako nije selektovan
        item = self.tree.identify_row(event.y)
        if item:
            if item not in self.tree.selection():
                self.tree.selection_set(item)
                self.tree.focus(item)
        selection = self.tree.selection()
        if not selection:
            return
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        menu = tk.Menu(self.root, tearoff=0,
                       bg=colors['section_bg'], fg=colors['fg'],
                       activebackground='#34495e', activeforeground='white',
                       font=('Segoe UI', 11), relief=tk.FLAT, bd=2)
        
        # Detaljni pregled
        menu.add_command(label="   👁️  Detaljni Pregled   ",
                         command=self.detaljni_pregled,
                         compound='left')
        menu.add_separator()
        
        # Dodeli proizvod/paket
        if len(selection) == 1:
            menu.add_command(label="   📦  Dodeli Proizvod   ",
                             command=self.dodeli_paket_dijalog,
                             compound='left')
            menu.add_command(label="   📝  Dodaj Belešku   ",
                             command=self.dodaj_belesku_dijalog,
                             compound='left')
            menu.add_separator()
        
        # Obriši selektovane klijente
        menu.add_command(label="   🗑️  Obriši   ",
                         command=self.obrisi_klijenta_dijalog,
                         compound='left')
        
        # Osveži listu
        menu.add_command(label="   🔄  Osveži   ",
                         command=self.ucitaj_klijente,
                         compound='left')
        
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
    
    def setup_overview_tab(self):
        """Setup za Overview tab - statistike i grafikoni"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.overview_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Poziv postojeće overview funkcionalnosti ali integrisano u tab
        self.load_overview_content(content)
    
    def load_overview_content(self, parent_frame):
        """Pregled: grafikoni gore, totali sredina, detalji proizvoda dole (scrollable)."""
        colors = self.dark_colors if self.dark_mode else self.light_colors

        # Glavni canvas za scroll celog sadržaja
        main_canvas = tk.Canvas(parent_frame, bg=colors['bg'], highlightthickness=0)
        main_scrollbar = ttk.Scrollbar(parent_frame, orient="vertical", command=main_canvas.yview)
        scrollable_content = tk.Frame(main_canvas, bg=colors['bg'])
        
        def update_scroll_region(event=None):
            main_canvas.configure(scrollregion=main_canvas.bbox("all"))
        
        def on_canvas_configure(event):
            # Kada se canvas resize-uje, ažuriraj širinu scrollable frame-a
            canvas_width = event.width
            main_canvas.itemconfig(canvas_window, width=canvas_width)
        
        scrollable_content.bind("<Configure>", update_scroll_region)
        canvas_window = main_canvas.create_window((0, 0), window=scrollable_content, anchor="nw")
        main_canvas.bind("<Configure>", on_canvas_configure)
        main_canvas.configure(yscrollcommand=main_scrollbar.set)

        # Kontrole (zajednički period)
        controls = tk.Frame(scrollable_content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        controls.pack(fill=tk.X, pady=(0, 12), padx=0)
        inner = tk.Frame(controls, bg=colors['section_bg'])
        inner.pack(side=tk.RIGHT, padx=15, pady=8)
        tk.Label(inner, text='Period:', font=('Segoe UI', 10), bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT, padx=(0,8))
        self.overview_period = getattr(self, 'overview_period', tk.StringVar(value='Mesečno'))
        if isinstance(self.overview_period, str):
            self.overview_period = tk.StringVar(value=self.overview_period)
        period_box = ttk.Combobox(inner, textvariable=self.overview_period, values=['Dnevno','Nedeljno','Mesečno','Godišnje'], width=12)
        period_box.pack(side=tk.LEFT)

        def refresh_graphs():
            period = self.overview_period.get()
            self.render_overview_graph_on(self.overview_canvas_paketi, 'paketi', period)
            self.render_overview_graph_on(self.overview_canvas_klijenti, 'klijenti', period)
            self.render_revenue_totals(self.revenue_frame)
            self.render_product_details(self.product_details_frame)

        action_btn = tk.Button(inner, text='Prikaži', command=refresh_graphs,
                               font=('Segoe UI', 10, 'bold'), bg='#3498db', fg='white', padx=18, pady=8, border=0, relief=tk.FLAT)
        action_btn.pack(side=tk.LEFT, padx=(8,0))
        self.add_button_hover(action_btn, '#3498db', '#5dade2')

        # Sekcija grafikona: Paketi gore
        graphs = tk.Frame(scrollable_content, bg=colors['bg'])
        graphs.pack(fill=tk.X, expand=False, padx=0)

        paketi_wrap = tk.Frame(graphs, bg=colors['bg'])
        paketi_wrap.pack(fill=tk.X, expand=False, padx=15, pady=(8, 4))
        self.overview_canvas_paketi = tk.Canvas(paketi_wrap, bg=colors['bg'], highlightthickness=0, height=180)
        self.overview_canvas_paketi.pack(fill=tk.X, expand=False)

        # Klijenti dole
        klijenti_wrap = tk.Frame(graphs, bg=colors['bg'])
        klijenti_wrap.pack(fill=tk.X, expand=False, padx=15, pady=(4, 8))
        self.overview_canvas_klijenti = tk.Canvas(klijenti_wrap, bg=colors['bg'], highlightthickness=0, height=180)
        self.overview_canvas_klijenti.pack(fill=tk.X, expand=False)

        # Totali ispod
        self.revenue_frame = tk.Frame(scrollable_content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        self.revenue_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        # Detalji po proizvodima
        self.product_details_frame = tk.Frame(scrollable_content, bg=colors['bg'])
        self.product_details_frame.pack(fill=tk.X, expand=False, padx=0, pady=(0, 10))

        # Pack canvas i scrollbar
        main_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        main_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Mouse wheel scrolling
        def on_mousewheel(event):
            main_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        main_canvas.bind_all("<MouseWheel>", on_mousewheel)

        # Prvi render
        refresh_graphs()

    def compute_overview_series(self, mode, period):
        """Vraća (labels, counts) za izabrani mod i period"""
        from datetime import datetime, timedelta
        now = datetime.now()
        labels, buckets = [], []

        def round_week(dt):
            return dt - timedelta(days=dt.weekday())

        if period == 'Dnevno':
            # poslednjih 7 dana
            for i in range(6,-1,-1):
                d = now.date() - timedelta(days=i)
                labels.append(d.strftime('%d.%m'))
                buckets.append((datetime(d.year,d.month,d.day), datetime(d.year,d.month,d.day,23,59,59)))
        elif period == 'Nedeljno':
            start = round_week(now)
            for i in range(7,-1,-1):
                s = start - timedelta(weeks=i)
                e = s + timedelta(days=6, hours=23, minutes=59, seconds=59)
                labels.append(s.strftime('W%W'))
                buckets.append((s, e))
        elif period == 'Mesečno':
            # dani tekućeg meseca
            first = now.replace(day=1)
            nextm = (first.replace(day=28) + timedelta(days=4)).replace(day=1)
            days = (nextm - first).days
            for i in range(1, days+1):
                s = first.replace(day=i)
                e = s.replace(hour=23, minute=59, second=59)
                labels.append(str(i))
                buckets.append((s, e))
        else:  # Godišnje
            for m in range(1,13):
                s = now.replace(month=m, day=1, hour=0, minute=0, second=0)
                if m == 12:
                    e = now.replace(year=now.year+1, month=1, day=1) - timedelta(seconds=1)
                else:
                    e = now.replace(month=m+1, day=1) - timedelta(seconds=1)
                labels.append(s.strftime('%b'))
                buckets.append((s, e))

        # Skupljanje timestampova
        timestamps = []
        if mode == 'paketi':
            for klijent in self.menadzer.klijenti.values():
                for paket in klijent['paketi']:
                    ds = paket.get('datum_dodele')
                    if not ds:
                        continue
                    try:
                        from datetime import datetime as _dt
                        timestamps.append(_dt.strptime(ds, '%Y-%m-%d %H:%M:%S'))
                    except Exception:
                        continue
        else:  # klijenti
            for k in self.menadzer.klijenti.values():
                ds = k.get('kreiran')
                if not ds:
                    continue
                try:
                    from datetime import datetime as _dt
                    timestamps.append(_dt.strptime(ds, '%Y-%m-%d %H:%M:%S'))
                except Exception:
                    continue

        counts = [0]*len(buckets)
        for ts in timestamps:
            for i,(s,e) in enumerate(buckets):
                if s <= ts <= e:
                    counts[i] += 1
                    break

        return labels, counts

    def render_overview_graph_on(self, canvas, mode, period):
        colors = self.dark_colors if self.dark_mode else self.light_colors
        if not canvas:
            return
        canvas.delete('all')

        labels, counts = self.compute_overview_series(mode, period)

        # Dimenzije i skaliranje
        w = canvas.winfo_width() or 900
        h = canvas.winfo_height() or 360
        margin = 50
        x0, y0 = margin, h - margin
        x1, y1 = w - margin, margin

        # Ose
        canvas.create_line(x0, y0, x1, y0, fill=colors['fg'])
        canvas.create_line(x0, y0, x0, y1, fill=colors['fg'])

        n = max(1, len(counts))
        bar_w = (x1 - x0) / (n*1.3)
        gap = bar_w*0.3
        max_val = max(counts) if any(counts) else 1
        bar_color = '#27ae60' if mode=='paketi' else '#3498db'

        # Titl
        title = 'Paketi prodata' if mode=='paketi' else 'Novi klijenti'
        canvas.create_text((w//2), 18, text=f"{title} — {period}", fill=colors['fg'], font=('Segoe UI', 11, 'bold'))

        rects = []
        targets = []
        for i, val in enumerate(counts):
            x_left = x0 + i*(bar_w+gap) + gap
            x_right = x_left + bar_w
            y_top = y0 - (val/max_val) * (y0 - y1 - 10)
            r = canvas.create_rectangle(x_left, y0, x_right, y0, fill=bar_color, outline='')
            rects.append(r)
            targets.append(y_top)
            # Labela ispod
            canvas.create_text((x_left+x_right)/2, y0+12, text=labels[i], fill=colors['fg'], font=('Segoe UI', 8))

        # Animacija rasta stubaca
        def step_anim():
            done = True
            for i, r in enumerate(rects):
                x_l, y_t, x_r, y_b = canvas.coords(r)
                target = targets[i]
                if y_t > target:
                    new_t = max(target, y_t - 12)
                    canvas.coords(r, x_l, new_t, x_r, y_b)
                    done = False
            if not done:
                canvas.after(16, step_anim)

        step_anim()

    def render_overview_graph(self):
        """Zadržano za kompatibilnost: renderuje oba"""
        period = self.overview_period.get() if hasattr(self.overview_period, 'get') else 'Mesečno'
        self.render_overview_graph_on(getattr(self, 'overview_canvas_paketi', None), 'paketi', period)
        self.render_overview_graph_on(getattr(self, 'overview_canvas_klijenti', None), 'klijenti', period)

    def render_revenue_totals(self, frame):
        """Prikazuje zaradu: tekući mesec, tekuća godina i UKUPNO."""
        from datetime import datetime
        colors = self.dark_colors if self.dark_mode else self.light_colors
        for w in frame.winfo_children():
            w.destroy()

        # Izračun
        now = datetime.now()
        month_total = 0.0
        year_total = 0.0
        lifetime_total = 0.0
        for klijent in self.menadzer.klijenti.values():
            for paket in klijent.get('paketi', []):
                cena = 0.0
                try:
                    cena = float(paket.get('cena', 0) or 0)
                except Exception:
                    pass
                lifetime_total += cena
                ds = paket.get('datum_dodele')
                if not ds:
                    continue
                try:
                    dt = datetime.strptime(ds, '%Y-%m-%d %H:%M:%S')
                except Exception:
                    continue
                if dt.year == now.year:
                    year_total += cena
                    if dt.month == now.month:
                        month_total += cena

        # Prikaz
        header = tk.Frame(frame, bg=colors['header'])
        header.pack(fill=tk.X)
        tk.Label(header, text='💰 Ukupna zarada', font=('Segoe UI', 12, 'bold'), bg=colors['header'], fg='white').pack(padx=12, pady=8, anchor='w')

        content = tk.Frame(frame, bg=colors['section_bg'])
        content.pack(fill=tk.X, padx=12, pady=10)

        left = tk.Frame(content, bg=colors['section_bg'])
        left.pack(side=tk.LEFT, padx=8)
        tk.Label(left, text='Mesec:', font=('Segoe UI', 10), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor='w')
        tk.Label(left, text=f"{month_total:,.0f} din", font=('Segoe UI', 16, 'bold'), bg=colors['section_bg'], fg='#27ae60').pack(anchor='w')

        middle = tk.Frame(content, bg=colors['section_bg'])
        middle.pack(side=tk.LEFT, padx=24)
        tk.Label(middle, text='Godina:', font=('Segoe UI', 10), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor='w')
        tk.Label(middle, text=f"{year_total:,.0f} din", font=('Segoe UI', 16, 'bold'), bg=colors['section_bg'], fg='#27ae60').pack(anchor='w')

        totalf = tk.Frame(content, bg=colors['section_bg'])
        totalf.pack(side=tk.LEFT, padx=24)
        tk.Label(totalf, text='Ukupno:', font=('Segoe UI', 10), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor='w')
        tk.Label(totalf, text=f"{lifetime_total:,.0f} din", font=('Segoe UI', 16, 'bold'), bg=colors['section_bg'], fg='#27ae60').pack(anchor='w')
    
    def render_product_details(self, frame):
        """Prikazuje detalje po proizvodima sa lifetime, mesečnom i godišnjom zaradom"""
        from datetime import datetime
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        for w in frame.winfo_children():
            w.destroy()
        
        # Sakupljanje podataka
        now = datetime.now()
        product_data = {}  # {naziv: {'lifetime': 0, 'year': 0, 'month': 0, 'count': 0}}
        
        for klijent in self.menadzer.klijenti.values():
            for paket in klijent.get('paketi', []):
                naziv = paket.get('naziv', 'Nepoznat')
                try:
                    cena = float(paket.get('cena', 0) or 0)
                except:
                    cena = 0.0
                
                if naziv not in product_data:
                    product_data[naziv] = {'lifetime': 0, 'year': 0, 'month': 0, 'count': 0}
                
                product_data[naziv]['lifetime'] += cena
                product_data[naziv]['count'] += 1
                
                ds = paket.get('datum_dodele')
                if ds:
                    try:
                        dt = datetime.strptime(ds, '%Y-%m-%d %H:%M:%S')
                        if dt.year == now.year:
                            product_data[naziv]['year'] += cena
                            if dt.month == now.month:
                                product_data[naziv]['month'] += cena
                    except:
                        pass
        
        if not product_data:
            no_data_frame = tk.Frame(frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
            no_data_frame.pack(fill=tk.X, padx=15, pady=10)
            tk.Label(no_data_frame, text="📦 Detalji Po Proizvodima", 
                    font=('Segoe UI', 13, 'bold'), bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=10)
            tk.Label(no_data_frame, text="Nema podataka o proizvodima", 
                    font=('Segoe UI', 12), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(pady=20)
            return
        
        # Header
        header = tk.Frame(frame, bg=colors['header'], relief=tk.RIDGE, bd=2)
        header.pack(fill=tk.X, padx=15, pady=(0,10))
        tk.Label(header, text='📦 Detalji Po Proizvodima', font=('Segoe UI', 13, 'bold'), 
                bg=colors['header'], fg='white').pack(padx=15, pady=12, anchor='w')
        
        # Sortiraj proizvode po lifetime zaradi
        sorted_products = sorted(product_data.items(), key=lambda x: x[1]['lifetime'], reverse=True)
        
        # Direktno dodaj kartice proizvoda (bez dodatnog canvasa)
        for naziv, stats in sorted_products:
            product_card = tk.Frame(frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
            product_card.pack(fill=tk.X, padx=15, pady=8)
            
            # Naziv proizvoda
            title_frame = tk.Frame(product_card, bg=colors['header'])
            title_frame.pack(fill=tk.X)
            tk.Label(title_frame, text=f"📦 {naziv}", font=('Segoe UI', 13, 'bold'),
                    bg=colors['header'], fg='white').pack(anchor=tk.W, padx=15, pady=10)
            
            # Broj prodatih
            info_frame = tk.Frame(product_card, bg=colors['section_bg'])
            info_frame.pack(fill=tk.X, padx=15, pady=(10, 5))
            tk.Label(info_frame, text=f"Prodato: {stats['count']}x", 
                    font=('Segoe UI', 11, 'bold'), bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W)
            
            # Grid za prikaz zarade
            stats_grid = tk.Frame(product_card, bg=colors['section_bg'])
            stats_grid.pack(fill=tk.X, padx=15, pady=(5, 15))
            
            # Lifetime
            lifetime_box = tk.Frame(stats_grid, bg='#27ae60', relief=tk.FLAT)
            lifetime_box.grid(row=0, column=0, padx=5, pady=5, sticky='ew')
            tk.Label(lifetime_box, text='💎 Lifetime', font=('Segoe UI', 9, 'bold'), 
                    bg='#27ae60', fg='white').pack(pady=(8, 2))
            tk.Label(lifetime_box, text=f"{stats['lifetime']:,.0f} din", 
                    font=('Segoe UI', 14, 'bold'), bg='#27ae60', fg='white').pack(pady=(0, 8))
            
            # Godišnje
            year_box = tk.Frame(stats_grid, bg='#3498db', relief=tk.FLAT)
            year_box.grid(row=0, column=1, padx=5, pady=5, sticky='ew')
            tk.Label(year_box, text='📅 Ove godine', font=('Segoe UI', 9, 'bold'), 
                    bg='#3498db', fg='white').pack(pady=(8, 2))
            tk.Label(year_box, text=f"{stats['year']:,.0f} din", 
                    font=('Segoe UI', 14, 'bold'), bg='#3498db', fg='white').pack(pady=(0, 8))
            
            # Mesečno
            month_box = tk.Frame(stats_grid, bg='#9b59b6', relief=tk.FLAT)
            month_box.grid(row=0, column=2, padx=5, pady=5, sticky='ew')
            tk.Label(month_box, text='📆 Ovaj mesec', font=('Segoe UI', 9, 'bold'), 
                    bg='#9b59b6', fg='white').pack(pady=(8, 2))
            tk.Label(month_box, text=f"{stats['month']:,.0f} din", 
                    font=('Segoe UI', 14, 'bold'), bg='#9b59b6', fg='white').pack(pady=(0, 8))
            
            # Podesi kolone da budu iste širine
            for i in range(3):
                stats_grid.columnconfigure(i, weight=1)
    
    def setup_schedule_tab(self):
        """Setup za Schedule tab - kalendar sa zadacima"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.schedule_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Header
        header_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(header_frame, text="📅 Raspored Zadataka", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=20, pady=15)
        
        # Dodaj dugme za novi zadatak
        button_frame = tk.Frame(content, bg=colors['bg'])
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        add_task_btn = tk.Button(button_frame, text="➕ Dodaj Novi Zadatak", 
                                command=self.dodaj_schedule_zadatak,
                                font=('Segoe UI', 11, 'bold'), bg='#3498db', fg='white',
                                padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_task_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_task_btn, '#3498db', '#5dade2')
        
        # Tabela sa zadacima
        schedule_frame = ttk.Frame(content, style='Main.TFrame')
        schedule_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(schedule_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.schedule_tree = ttk.Treeview(schedule_frame,
                                         columns=('Datum', 'Dan', 'Klijent', 'Zadatak', 'Status'),
                                         height=20, yscrollcommand=scrollbar.set, style=tree_style,
                                         selectmode='extended')
        scrollbar.config(command=self.schedule_tree.yview)
        
        self.schedule_tree.column('#0', width=0, stretch=tk.NO)
        self.schedule_tree.column('Datum', anchor=tk.CENTER, width=100)
        self.schedule_tree.column('Dan', anchor=tk.CENTER, width=100)
        self.schedule_tree.column('Klijent', anchor=tk.W, width=200)
        self.schedule_tree.column('Zadatak', anchor=tk.W, width=300)
        self.schedule_tree.column('Status', anchor=tk.CENTER, width=120)
        
        for col in self.schedule_tree['columns']:
            self.schedule_tree.heading(col, text=col)
        
        self.schedule_tree.pack(fill=tk.BOTH, expand=True)
        self.schedule_tree.bind('<Double-Button-1>', lambda e: self.edit_schedule_zadatak())
        self.schedule_tree.bind('<Button-3>', lambda e: self.schedule_right_click_menu(e))
        
        # Učitaj zadatke
        self.ucitaj_schedule_zadatke()
    
    def setup_outreach_tab(self):
        """Setup za Outreach tab - praćenje outreach poruka"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.outreach_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Header
        header_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(header_frame, text="📧 Outreach Praćenje", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=20, pady=15)
        
        # Dodaj dugme za novi outreach
        button_frame = tk.Frame(content, bg=colors['bg'])
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        add_outreach_btn = tk.Button(button_frame, text="➕ Dodaj Novi Outreach", 
                                     command=self.dodaj_outreach,
                                     font=('Segoe UI', 11, 'bold'), bg='#e74c3c', fg='white',
                                     padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_outreach_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_outreach_btn, '#e74c3c', '#ec7063')
        
        # Tabela sa outreach-ima
        outreach_frame = ttk.Frame(content, style='Main.TFrame')
        outreach_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(outreach_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.outreach_tree = ttk.Treeview(outreach_frame,
                                         columns=('Datum', 'Klijent', 'Email', 'Status', 'Napomene'),
                                         height=20, yscrollcommand=scrollbar.set, style=tree_style,
                                         selectmode='extended')
        scrollbar.config(command=self.outreach_tree.yview)
        
        self.outreach_tree.column('#0', width=0, stretch=tk.NO)
        self.outreach_tree.column('Datum', anchor=tk.CENTER, width=100)
        self.outreach_tree.column('Klijent', anchor=tk.W, width=150)
        self.outreach_tree.column('Email', anchor=tk.W, width=200)
        self.outreach_tree.column('Status', anchor=tk.CENTER, width=120)
        self.outreach_tree.column('Napomene', anchor=tk.W, width=350)
        
        for col in self.outreach_tree['columns']:
            self.outreach_tree.heading(col, text=col)
        
        self.outreach_tree.pack(fill=tk.BOTH, expand=True)
        self.outreach_tree.bind('<Double-Button-1>', lambda e: self.edit_outreach())
        self.outreach_tree.bind('<Button-3>', lambda e: self.outreach_right_click_menu(e))
        
        # Učitaj outreach podatke
        self.ucitaj_outreach_podatke()
    
    def darker_color(self, hex_color):
        hex_color = hex_color.lstrip('#')
        return '#' + ''.join([hex(max(0, int(hex_color[i:i+2], 16) - 30))[2:].zfill(2) for i in (0, 2, 4)])
    
    def lighter_color(self, hex_color):
        hex_color = hex_color.lstrip('#')
        return '#' + ''.join([hex(min(255, int(hex_color[i:i+2], 16) + 20))[2:].zfill(2) for i in (0, 2, 4)])
    
    def add_button_hover(self, button, normal_color, hover_color):
        def on_enter(e):
            button['background'] = hover_color
        def on_leave(e):
            button['background'] = normal_color
        button.bind('<Enter>', on_enter)
        button.bind('<Leave>', on_leave)
    
    def fade_in(self, window, alpha=0.0):
        if alpha < 1.0:
            alpha += 0.1
            window.attributes('-alpha', alpha)
            window.after(20, lambda: self.fade_in(window, alpha))
        else:
            window.attributes('-alpha', 1.0)
    
    def show_settings(self):
        """Prikazuje settings dialog"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("⚙️ Podešavanja")
        dialog.geometry("450x450")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="⚙️ Podešavanja", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Dark Mode Section
        dark_section = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=1)
        dark_section.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(dark_section, text="🌙 Tamna Tema", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(15, 5))
        
        tk.Label(dark_section, text="Omogući tamnu temu za udobniji rad",
                font=('Segoe UI', 9), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15)
        
        dark_frame = tk.Frame(dark_section, bg=colors['section_bg'])
        dark_frame.pack(anchor=tk.W, padx=15, pady=(10, 15))
        
        def toggle_dark_in_settings():
            self.toggle_dark_mode()
            # Zatvori i ponovo otvori settings da se primeni tema
            dialog.destroy()
            self.show_settings()
        
        dark_mode_btn = tk.Button(dark_frame, 
                                  text="ON" if self.dark_mode else "OFF",
                                  command=toggle_dark_in_settings,
                                  font=('Segoe UI', 10, 'bold'),
                                  bg='#27ae60' if self.dark_mode else '#95a5a6',
                                  fg='white', padx=20, pady=5, border=0,
                                  cursor='hand2', relief=tk.FLAT)
        dark_mode_btn.pack(side=tk.LEFT)
        self.add_button_hover(dark_mode_btn, 
                            '#27ae60' if self.dark_mode else '#95a5a6',
                            '#2ecc71' if self.dark_mode else '#a6b4b6')
        
        # Inactivity Timer Section
        timer_section = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=1)
        timer_section.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(timer_section, text="⏱️ Tajmer Neaktivnosti", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(15, 5))
        
        tk.Label(timer_section, text="Automatska odjava nakon perioda neaktivnosti",
                font=('Segoe UI', 9), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15)
        
        timer_frame = tk.Frame(timer_section, bg=colors['section_bg'])
        timer_frame.pack(anchor=tk.W, padx=15, pady=(10, 15))
        
        tk.Label(timer_frame, text="Minuta:", font=('Segoe UI', 10),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT, padx=(0, 10))
        
        timer_var = tk.IntVar(value=self.inactivity_timeout // 60)
        timer_spinbox = tk.Spinbox(timer_frame, from_=1, to=60, textvariable=timer_var,
                                   font=('Segoe UI', 11), width=8, relief=tk.FLAT, bd=2)
        timer_spinbox.pack(side=tk.LEFT)
        
        def save_settings():
            # Sačuvaj tajmer
            new_timeout = timer_var.get() * 60
            if new_timeout != self.inactivity_timeout:
                self.inactivity_timeout = new_timeout
                self.reset_timer()
            
            messagebox.showinfo("Uspeh", "Podešavanja su uspešno sačuvana!")
            dialog.destroy()
        
        # Save and Close buttons
        btn_frame = tk.Frame(content, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(20, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=save_settings,
                            font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                            padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=(0, 8))
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        close_btn = tk.Button(btn_frame, text="✕ Zatvori", command=dialog.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.LEFT)
        self.add_button_hover(close_btn, '#95a5a6', '#a6b4b6')
    
    def toggle_dark_mode(self):
        self.dark_mode = not self.dark_mode
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Update TTK styles
        self.setup_style()
        
        # Update settings button if it exists
        if hasattr(self, 'dark_mode_setting_btn'):
            self.dark_mode_setting_btn.config(
                text="ON" if self.dark_mode else "OFF",
                bg='#27ae60' if self.dark_mode else '#95a5a6'
            )
            if self.dark_mode:
                self.add_button_hover(self.dark_mode_setting_btn, '#27ae60', '#2ecc71')
            else:
                self.add_button_hover(self.dark_mode_setting_btn, '#95a5a6', '#7f8c8d')
        
        # Update main window
        self.root.configure(bg=colors['bg'])
        
        # Update tree if it exists
        if hasattr(self, 'tree'):
            if self.dark_mode:
                self.tree.configure(style='Dark.Treeview')
            else:
                self.tree.configure(style='Treeview')
        
        # Update frames if they exist
        if hasattr(self, 'main_frame'):
            self.main_frame.configure(style='Main.TFrame')
        if hasattr(self, 'header_frame'):
            self.header_frame.configure(style='Header.TFrame')

    def toggle_dark_and_refresh_login(self):
        """Preklapa tamnu temu i osvežava login ekran."""
        self.toggle_dark_mode()
        self.show_login_screen()

    def show_main_screen(self):
        """Gradi glavnu aplikaciju nakon uspešne prijave."""
        # Očisti prozor
        for widget in self.root.winfo_children():
            widget.destroy()

        colors = self.dark_colors if self.dark_mode else self.light_colors
        self.root.title("Menadžer Klijenata")
        self.root.configure(bg=colors['bg'])

        # Glavni frejm
        self.main_frame = ttk.Frame(self.root, style='Main.TFrame')
        self.main_frame.pack(fill=tk.BOTH, expand=True)

        # Header i tabovi
        self.setup_header()
        self.setup_notebook()

        # Aktivnost i auto-logout
        self.root.bind_all('<Key>', self.reset_timer)
        self.root.bind_all('<Button>', self.reset_timer)
        self.start_inactivity_timer()
    
    def ucitaj_klijente(self, preserve_selection=True):
        # Zapamti trenutno selektovanog klijenta
        selected_id = None
        if preserve_selection:
            selected = self.tree.selection()
            if selected:
                try:
                    selected_id = str(self.tree.item(selected[0])['values'][0]).strip()
                except:
                    pass
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Popuni tabelu i zapamti item za ponovno selektovanje
        item_to_select = None
        for id_klijenta in sorted(self.menadzer.klijenti.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            klijent = self.menadzer.klijenti[id_klijenta]
            item = self.tree.insert('', tk.END, text='',
                           values=(id_klijenta, klijent['ime'], klijent['prezime'],
                                 klijent['email'], klijent['telefon'],
                                 len(klijent['paketi']), len(klijent['beleske'])))
            if selected_id and id_klijenta == selected_id:
                item_to_select = item
        
        # Ponovo selektuj klijenta ako je bio selektovan
        if item_to_select:
            self.tree.selection_set(item_to_select)
            self.tree.focus(item_to_select)
            self.tree.see(item_to_select)
    
    def ucitaj_schedule_zadatke(self):
        """Učitava schedule zadatke iz JSON fajla"""
        if not hasattr(self, 'schedule_tree'):
            return
            
        self.schedule_tree.delete(*self.schedule_tree.get_children())
        
        # Učitaj schedule podatke - osvezi iz fajla
        self.menadzer.schedule_data = self.menadzer.ucitaj_schedule()
        
        for task_id, task in self.menadzer.schedule_data.items():
            self.schedule_tree.insert('', tk.END, values=(
                task['datum'],
                task['dan'],
                task['klijent'],
                task['zadatak'],
                task['status']
            ), tags=(task_id,))
    
    def ucitaj_outreach_podatke(self):
        """Učitava outreach podatke iz JSON fajla"""
        if not hasattr(self, 'outreach_tree'):
            return
            
        self.outreach_tree.delete(*self.outreach_tree.get_children())
        
        # Učitaj outreach podatke - osveži iz fajla
        self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
        outreach_data = self.menadzer.outreach_data
        
        for outreach_id, outreach in outreach_data.items():
            self.outreach_tree.insert('', tk.END, values=(
                outreach['datum'],
                outreach['klijent'],
                outreach['email'],
                outreach['status'],
                outreach.get('napomene', '')
            ), tags=(outreach_id,))
    
    def dodaj_schedule_zadatak(self):
        """Dijalog za dodavanje novog schedule zadatka"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novi Zadatak")
        dialog.geometry("500x550")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (dialog.winfo_screenheight() // 2) - (550 // 2)
        dialog.geometry(f"500x550+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="📅 Novi Zadatak", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        fields = []
        
        # Datum
        tk.Label(content, text="Datum:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        datum_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        datum_entry.pack(fill=tk.X, ipady=8)
        datum_entry.insert(0, datetime.now().strftime('%d.%m.%Y'))
        fields.append(('datum', datum_entry))
        
        # Dan
        tk.Label(content, text="Dan:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        dan_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                            fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        dan_entry.pack(fill=tk.X, ipady=8)
        days = ['Ponedeljak', 'Utorak', 'Sreda', 'Četvrtak', 'Petak', 'Subota', 'Nedelja']
        dan_entry.insert(0, days[datetime.now().weekday()])
        fields.append(('dan', dan_entry))
        
        # Klijent dropdown
        tk.Label(content, text="Klijent:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        klijent_var = tk.StringVar()
        klijenti_lista = [f"{k['ime']} {k['prezime']}" for k in self.menadzer.klijenti.values()]
        
        klijent_combobox = ttk.Combobox(content, textvariable=klijent_var, 
                                       values=klijenti_lista, font=('Segoe UI', 11))
        klijent_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('klijent', klijent_combobox))
        
        # Zadatak
        tk.Label(content, text="Zadatak:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        zadatak_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                                fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        zadatak_entry.pack(fill=tk.X, ipady=8)
        fields.append(('zadatak', zadatak_entry))
        
        # Status dropdown
        tk.Label(content, text="Status:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        status_var = tk.StringVar(value="⏳ Na Čekanju")
        status_combobox = ttk.Combobox(content, textvariable=status_var, 
                                      values=["⏳ Na Čekanju", "🔄 U Toku", "✅ Završeno"],
                                      font=('Segoe UI', 11), state='readonly')
        status_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('status', status_combobox))
        
        # Buttons
        btn_frame = tk.Frame(dialog, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=30, pady=(0, 20))
        
        def sacuvaj():
            data = {}
            for field_name, widget in fields:
                if isinstance(widget, ttk.Combobox):
                    value = widget.get()
                else:
                    value = widget.get()
                    
                if not value and field_name not in ['status']:
                    messagebox.showwarning("Upozorenje", f"Molimo popunite polje: {field_name.capitalize()}")
                    return
                    
                data[field_name] = value
            
            try:
                self.menadzer.dodaj_schedule_zadatak(data)
                self.ucitaj_schedule_zadatke()
                messagebox.showinfo("Uspeh", "Zadatak je uspešno dodat!")
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Došlo je do greške: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="💾 Sačuvaj", command=sacuvaj,
                           font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                           padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="❌ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(cancel_btn, '#95a5a6', '#b4bcc2')
    
    def dodaj_outreach(self):
        """Dijalog za dodavanje novog outreach-a"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novi Outreach")
        dialog.geometry("550x650")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (550 // 2)
        y = (dialog.winfo_screenheight() // 2) - (650 // 2)
        dialog.geometry(f"550x650+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="📧 Novi Outreach", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        fields = []
        
        # Datum
        tk.Label(content, text="Datum:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        datum_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        datum_entry.pack(fill=tk.X, ipady=8)
        datum_entry.insert(0, datetime.now().strftime('%d.%m.%Y'))
        fields.append(('datum', datum_entry))
        
        # Klijent ime
        tk.Label(content, text="Ime Klijenta:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        klijent_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                                fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        klijent_entry.pack(fill=tk.X, ipady=8)
        fields.append(('klijent', klijent_entry))
        
        # Email
        tk.Label(content, text="Email:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        email_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        email_entry.pack(fill=tk.X, ipady=8)
        fields.append(('email', email_entry))
        
        # Status dropdown
        tk.Label(content, text="Status:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        status_var = tk.StringVar(value="📤 Poslato")
        status_combobox = ttk.Combobox(content, textvariable=status_var, 
                                      values=["📤 Poslato", "👀 Viđeno", "💬 Odgovoreno", "❌ Bez Odgovora"],
                                      font=('Segoe UI', 11), state='readonly')
        status_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('status', status_combobox))
        
        # Odgovor checkbox
        odgovor_var = tk.BooleanVar()
        odgovor_check = tk.Checkbutton(content, text="Klijent je odgovorio", variable=odgovor_var,
                                      font=('Segoe UI', 10), bg=colors['bg'], fg=colors['fg'],
                                      selectcolor=colors['section_bg'], activebackground=colors['bg'],
                                      activeforeground=colors['fg'])
        odgovor_check.pack(anchor=tk.W, pady=(15, 5))
        fields.append(('odgovor', odgovor_var))
        
        # Napomene
        tk.Label(content, text="Napomene:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        napomene_text = tk.Text(content, font=('Segoe UI', 10), bg=colors['section_bg'], 
                               fg=colors['fg'], relief=tk.FLAT, height=5, insertbackground=colors['fg'])
        napomene_text.pack(fill=tk.BOTH, expand=True)
        fields.append(('napomene', napomene_text))
        
        # Buttons
        btn_frame = tk.Frame(dialog, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=30, pady=(10, 20))
        
        def sacuvaj():
            data = {}
            for field_name, widget in fields:
                if isinstance(widget, ttk.Combobox):
                    value = widget.get()
                elif isinstance(widget, tk.BooleanVar):
                    value = widget.get()
                elif isinstance(widget, tk.Text):
                    value = widget.get('1.0', tk.END).strip()
                else:
                    value = widget.get()
                
                if not value and field_name not in ['napomene', 'odgovor']:
                    messagebox.showwarning("Upozorenje", f"Molimo popunite polje: {field_name.capitalize()}")
                    return
                    
                data[field_name] = value
            
            try:
                self.menadzer.dodaj_outreach(data)
                self.ucitaj_outreach_podatke()
                messagebox.showinfo("Uspeh", "Outreach je uspešno dodat!")
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Došlo je do greške: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="💾 Sačuvaj", command=sacuvaj,
                           font=('Segoe UI', 11, 'bold'), bg='#e74c3c', fg='white',
                           padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#e74c3c', '#ec7063')
        
        cancel_btn = tk.Button(btn_frame, text="❌ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(cancel_btn, '#95a5a6', '#b4bcc2')
    
    def schedule_right_click_menu(self, event):
        """Prikazuje context menu za schedule zadatke"""
        selection = self.schedule_tree.selection()
        if not selection:
            return
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Kreiraj popup menu sa većim fontom i padding-om
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=colors['section_bg'], fg=colors['fg'],
                      activebackground='#3498db', activeforeground='white',
                      font=('Segoe UI', 11), relief=tk.FLAT, bd=2)
        
        # Status submenu sa većim fontom
        status_menu = tk.Menu(menu, tearoff=0, 
                             bg=colors['section_bg'], fg=colors['fg'],
                             activebackground='#27ae60', activeforeground='white',
                             font=('Segoe UI', 11), relief=tk.FLAT, bd=1)
        
        # Opcije statusa sa boljim ikonicama i bojama
        status_menu.add_command(label="   ⏳  Na Čekanju   ", 
                               command=lambda: self.promeni_status_zadatka("⏳ Na Čekanju"),
                               compound='left')
        status_menu.add_command(label="   🔄  U Toku   ", 
                               command=lambda: self.promeni_status_zadatka("🔄 U Toku"),
                               compound='left')
        status_menu.add_command(label="   ✅  Završeno   ", 
                               command=lambda: self.promeni_status_zadatka("✅ Završeno"),
                               compound='left')
        
        # Dodaj opcije u glavni meni
        menu.add_cascade(label="   📝  Promeni Status   ", menu=status_menu)
        menu.add_separator()
        menu.add_command(label="   🗑️  Obriši Zadatak(e)   ", 
                        command=self.obrisi_schedule_zadatke)
        
        # Prikaži menu na poziciji miša
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
    
    def promeni_status_zadatka(self, novi_status):
        """Menja status selektovanih zadataka"""
        selection = self.schedule_tree.selection()
        if not selection:
            return
        
        try:
            # Osvezi podatke iz fajla pre promene
            self.menadzer.schedule_data = self.menadzer.ucitaj_schedule()
            print(f"Schedule data keys: {list(self.menadzer.schedule_data.keys())}")
            
            changed_count = 0
            for item in selection:
                tags = self.schedule_tree.item(item)['tags']
                if tags:
                    task_id = str(tags[0])  # Konvertuj u string
                    print(f"Menjam status zadatka ID: '{task_id}' (type: {type(task_id)}) na {novi_status}")
                    if task_id in self.menadzer.schedule_data:
                        self.menadzer.schedule_data[task_id]['status'] = novi_status
                        changed_count += 1
                        print(f"  ✓ Uspešno promenjen")
                    else:
                        print(f"  ✗ Task ID '{task_id}' nije pronađen u schedule_data")
                        print(f"  Dostupni ključevi: {list(self.menadzer.schedule_data.keys())}")
            
            if changed_count > 0:
                self.menadzer.sacuvaj_schedule()
                self.ucitaj_schedule_zadatke()
                messagebox.showinfo("Uspeh", f"Status {changed_count} zadataka je promenjen na: {novi_status}")
            else:
                messagebox.showwarning("Upozorenje", "Nijedan zadatak nije pronađen za izmenu.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Greška", f"Greška pri promeni statusa: {str(e)}")
    
    def obrisi_schedule_zadatke(self):
        """Briše selektovane schedule zadatke"""
        selection = self.schedule_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite zadatak(e) za brisanje.")
            return
        
        # Potvrda
        count = len(selection)
        odgovor = messagebox.askyesno("Potvrda", 
                                      f"Da li ste sigurni da želite da obrišete {count} zadatak(a)?")
        if not odgovor:
            return
        
        try:
            # Osvezi podatke iz fajla pre brisanja
            self.menadzer.schedule_data = self.menadzer.ucitaj_schedule()
            print(f"Schedule data keys pre brisanja: {list(self.menadzer.schedule_data.keys())}")
            
            deleted_count = 0
            for item in selection:
                tags = self.schedule_tree.item(item)['tags']
                if tags:
                    task_id = str(tags[0])  # Konvertuj u string
                    print(f"Brišem zadatak ID: '{task_id}' (type: {type(task_id)})")
                    if task_id in self.menadzer.schedule_data:
                        del self.menadzer.schedule_data[task_id]
                        deleted_count += 1
                        print(f"  ✓ Uspešno obrisan")
                    else:
                        print(f"  ✗ Task ID '{task_id}' nije pronađen")
                        print(f"  Dostupni ključevi: {list(self.menadzer.schedule_data.keys())}")
            
            if deleted_count > 0:
                self.menadzer.sacuvaj_schedule()
                self.ucitaj_schedule_zadatke()
                messagebox.showinfo("Uspeh", f"{deleted_count} zadatak(a) je uspešno obrisano!")
            else:
                messagebox.showwarning("Upozorenje", "Nijedan zadatak nije pronađen za brisanje.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Greška", f"Greška pri brisanju: {str(e)}")
    
    def edit_schedule_zadatak(self):
        """Izmena selektovanog schedule zadatka"""
        selection = self.schedule_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite zadatak za izmenu.")
            return
        
        # Ovde možeš dodati funkcionalnost za editovanje
        messagebox.showinfo("Info", "Funkcija za izmenu zadatka će uskoro biti dostupna!")
    
    def outreach_right_click_menu(self, event):
        """Prikazuje context menu za outreach"""
        selection = self.outreach_tree.selection()
        if not selection:
            return
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Kreiraj popup menu sa većim fontom i padding-om
        menu = tk.Menu(self.root, tearoff=0, 
                      bg=colors['section_bg'], fg=colors['fg'],
                      activebackground='#e74c3c', activeforeground='white',
                      font=('Segoe UI', 11), relief=tk.FLAT, bd=2)
        
        # Status submenu
        status_menu = tk.Menu(menu, tearoff=0, 
                             bg=colors['section_bg'], fg=colors['fg'],
                             activebackground='#9b59b6', activeforeground='white',
                             font=('Segoe UI', 11), relief=tk.FLAT, bd=1)
        
        status_menu.add_command(label="   📤  Poslato   ", 
                               command=lambda: self.promeni_status_outreach("📤 Poslato"),
                               compound='left')
        status_menu.add_command(label="   👀  Viđeno   ", 
                               command=lambda: self.promeni_status_outreach("👀 Viđeno"),
                               compound='left')
        status_menu.add_command(label="   💬  Odgovoreno   ", 
                               command=lambda: self.promeni_status_outreach("💬 Odgovoreno"),
                               compound='left')
        status_menu.add_command(label="   ❌  Bez Odgovora   ", 
                               command=lambda: self.promeni_status_outreach("❌ Bez Odgovora"),
                               compound='left')
        
        menu.add_cascade(label="   📝  Promeni Status   ", menu=status_menu)
        menu.add_separator()
        
        # Napomene opcije - samo ako je jedan outreach selektovan
        if len(selection) == 1:
            napomene_menu = tk.Menu(menu, tearoff=0, 
                                   bg=colors['section_bg'], fg=colors['fg'],
                                   activebackground='#f39c12', activeforeground='white',
                                   font=('Segoe UI', 11), relief=tk.FLAT, bd=1)
            
            napomene_menu.add_command(label="   ➕  Dodaj Napomenu   ", 
                                     command=self.dodaj_outreach_napomenu,
                                     compound='left')
            napomene_menu.add_command(label="   ✏️  Izmeni Napomenu   ", 
                                     command=self.izmeni_outreach_napomenu,
                                     compound='left')
            napomene_menu.add_command(label="   🗑️  Obriši Napomenu   ", 
                                     command=self.obrisi_outreach_napomenu,
                                     compound='left')
            
            menu.add_cascade(label="   📋  Napomene   ", menu=napomene_menu)
            menu.add_separator()
        
        menu.add_command(label="   🗑️  Obriši Outreach(e)   ", 
                        command=self.obrisi_outreach)
        
        # Prikaži menu na poziciji miša
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()
    
    def promeni_status_outreach(self, novi_status):
        """Menja status selektovanih outreach-a"""
        selection = self.outreach_tree.selection()
        if not selection:
            return
        
        try:
            # Osveži podatke iz fajla pre promene
            self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
            
            changed_count = 0
            for item in selection:
                tags = self.outreach_tree.item(item)['tags']
                if tags:
                    outreach_id = str(tags[0])
                    if outreach_id in self.menadzer.outreach_data:
                        self.menadzer.outreach_data[outreach_id]['status'] = novi_status
                        changed_count += 1
            
            if changed_count > 0:
                self.menadzer.sacuvaj_outreach()
                self.ucitaj_outreach_podatke()
                messagebox.showinfo("Uspeh", f"Status {changed_count} outreach-a je promenjen na: {novi_status}")
            else:
                messagebox.showwarning("Upozorenje", "Nijedan outreach nije pronađen za izmenu.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Greška", f"Greška pri promeni statusa: {str(e)}")
    
    def dodaj_outreach_napomenu(self):
        """Dodaje napomenu selektovanom outreach-u"""
        selection = self.outreach_tree.selection()
        if not selection or len(selection) != 1:
            return
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Dijalog za unos napomene
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Napomenu")
        dialog.geometry("450x300")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (450 // 2)
        y = (dialog.winfo_screenheight() // 2) - (300 // 2)
        dialog.geometry(f"450x300+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="📝 Dodaj Napomenu", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        tk.Label(content, text="Napomena:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        
        napomena_text = tk.Text(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                               fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'],
                               height=6, wrap=tk.WORD)
        napomena_text.pack(fill=tk.BOTH, expand=True)
        
        def sacuvaj_napomenu():
            napomena = napomena_text.get("1.0", tk.END).strip()
            if not napomena:
                messagebox.showwarning("Upozorenje", "Napomena ne može biti prazna.")
                return
            
            try:
                self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
                tags = self.outreach_tree.item(selection[0])['tags']
                if tags:
                    outreach_id = str(tags[0])
                    if outreach_id in self.menadzer.outreach_data:
                        self.menadzer.outreach_data[outreach_id]['napomene'] = napomena
                        self.menadzer.sacuvaj_outreach()
                        self.ucitaj_outreach_podatke()
                        messagebox.showinfo("Uspeh", "Napomena je uspešno dodata!")
                        dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Greška pri dodavanju napomene: {str(e)}")
        
        # Buttons
        btn_frame = tk.Frame(content, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(20, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sacuvaj_napomenu,
                            font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                            padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=(0, 8))
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        close_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.LEFT)
        self.add_button_hover(close_btn, '#95a5a6', '#a6b4b6')
    
    def izmeni_outreach_napomenu(self):
        """Izmena napomene selektovanog outreach-a"""
        selection = self.outreach_tree.selection()
        if not selection or len(selection) != 1:
            return
        
        # Učitaj trenutnu napomenu
        try:
            self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
            tags = self.outreach_tree.item(selection[0])['tags']
            if not tags:
                return
            
            outreach_id = str(tags[0])
            if outreach_id not in self.menadzer.outreach_data:
                return
            
            trenutna_napomena = self.menadzer.outreach_data[outreach_id].get('napomene', '')
        except Exception as e:
            messagebox.showerror("Greška", f"Greška pri učitavanju napomene: {str(e)}")
            return
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Dijalog za izmenu napomene
        dialog = tk.Toplevel(self.root)
        dialog.title("Izmeni Napomenu")
        dialog.geometry("450x300")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (450 // 2)
        y = (dialog.winfo_screenheight() // 2) - (300 // 2)
        dialog.geometry(f"450x300+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="✏️ Izmeni Napomenu", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        tk.Label(content, text="Napomena:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        
        napomena_text = tk.Text(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                               fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'],
                               height=6, wrap=tk.WORD)
        napomena_text.pack(fill=tk.BOTH, expand=True)
        napomena_text.insert("1.0", trenutna_napomena)
        
        def sacuvaj_izmene():
            napomena = napomena_text.get("1.0", tk.END).strip()
            if not napomena:
                messagebox.showwarning("Upozorenje", "Napomena ne može biti prazna.")
                return
            
            try:
                self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
                if outreach_id in self.menadzer.outreach_data:
                    self.menadzer.outreach_data[outreach_id]['napomene'] = napomena
                    self.menadzer.sacuvaj_outreach()
                    self.ucitaj_outreach_podatke()
                    messagebox.showinfo("Uspeh", "Napomena je uspešno izmenjena!")
                    dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Greška pri izmeni napomene: {str(e)}")
        
        # Buttons
        btn_frame = tk.Frame(content, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(20, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sacuvaj_izmene,
                            font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                            padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=(0, 8))
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        close_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.LEFT)
        self.add_button_hover(close_btn, '#95a5a6', '#a6b4b6')
    
    def obrisi_outreach_napomenu(self):
        """Briše napomenu selektovanog outreach-a"""
        selection = self.outreach_tree.selection()
        if not selection or len(selection) != 1:
            return
        
        odgovor = messagebox.askyesno("Potvrda", "Da li ste sigurni da želite da obrišete napomenu?")
        if not odgovor:
            return
        
        try:
            self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
            tags = self.outreach_tree.item(selection[0])['tags']
            if tags:
                outreach_id = str(tags[0])
                if outreach_id in self.menadzer.outreach_data:
                    self.menadzer.outreach_data[outreach_id]['napomene'] = ''
                    self.menadzer.sacuvaj_outreach()
                    self.ucitaj_outreach_podatke()
                    messagebox.showinfo("Uspeh", "Napomena je uspešno obrisana!")
        except Exception as e:
            messagebox.showerror("Greška", f"Greška pri brisanju napomene: {str(e)}")
    
    def obrisi_outreach(self):
        """Briše selektovane outreach-e"""
        selection = self.outreach_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite outreach(e) za brisanje.")
            return
        
        # Potvrda
        count = len(selection)
        odgovor = messagebox.askyesno("Potvrda", 
                                      f"Da li ste sigurni da želite da obrišete {count} outreach(a)?")
        if not odgovor:
            return
        
        try:
            # Osveži podatke iz fajla pre brisanja
            self.menadzer.outreach_data = self.menadzer.ucitaj_outreach()
            
            deleted_count = 0
            for item in selection:
                tags = self.outreach_tree.item(item)['tags']
                if tags:
                    outreach_id = str(tags[0])
                    if outreach_id in self.menadzer.outreach_data:
                        del self.menadzer.outreach_data[outreach_id]
                        deleted_count += 1
            
            if deleted_count > 0:
                self.menadzer.sacuvaj_outreach()
                self.ucitaj_outreach_podatke()
                messagebox.showinfo("Uspeh", f"{deleted_count} outreach(a) je uspešno obrisano!")
            else:
                messagebox.showwarning("Upozorenje", "Nijedan outreach nije pronađen za brisanje.")
        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Greška", f"Greška pri brisanju: {str(e)}")
    
    def edit_outreach(self):
        """Izmena selektovanog outreach-a"""
        selection = self.outreach_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite outreach za izmenu.")
            return
        
        # Ovde možeš dodati funkcionalnost za editovanje
        messagebox.showinfo("Info", "Funkcija za izmenu outreach-a će uskoro biti dostupna!")
    
    def pretrazi_klijente(self):
        """Pretražuje klijente po search query"""
        search_query = self.search_var.get().lower().strip()
        
        # Obriši trenutne rezultate
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Ako je search prazan, prikaži sve
        if not search_query:
            self.ucitaj_klijente(preserve_selection=False)
            return
        
        # Filtriraj i prikaži rezultate
        for id_klijenta in sorted(self.menadzer.klijenti.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            klijent = self.menadzer.klijenti[id_klijenta]
            
            # Proveri da li se match nalazi u bilo kom polju
            if (search_query in klijent['ime'].lower() or 
                search_query in klijent['prezime'].lower() or
                search_query in klijent['email'].lower() or
                search_query in klijent['telefon'].lower()):
                
                self.tree.insert('', tk.END, text='',
                               values=(id_klijenta, klijent['ime'], klijent['prezime'],
                                     klijent['email'], klijent['telefon'],
                                     len(klijent['paketi']), len(klijent['beleske'])))
    
    def show_overview(self):
        """Prikazuje overview tab sa statistikama i zaradom"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        overview_window = tk.Toplevel(self.root)
        overview_window.title("📊 Pregled Prihoda")
        overview_window.geometry("900x700")
        overview_window.transient(self.root)
        overview_window.attributes('-alpha', 0.0)
        self.fade_in(overview_window)
        overview_window.configure(bg=colors['bg'])
        
        # Header
        header = tk.Frame(overview_window, bg=colors['header'], height=70)
        header.pack(fill=tk.X)
        tk.Label(header, text="📊 Pregled Prihoda Po Paketima", 
                font=('Segoe UI', 18, 'bold'), bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(overview_window, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Izračunaj statistike
        paket_stats = {}
        ukupno_klijenata = len(self.menadzer.klijenti)
        ukupna_zarada = 0
        
        for klijent in self.menadzer.klijenti.values():
            for paket in klijent['paketi']:
                naziv = paket['naziv']
                cena = float(paket['cena'])
                
                if naziv not in paket_stats:
                    paket_stats[naziv] = {'count': 0, 'total': 0}
                
                paket_stats[naziv]['count'] += 1
                paket_stats[naziv]['total'] += cena
                ukupna_zarada += cena
        
        # Summary section
        summary_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        summary_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(summary_frame, text="💰 Ukupna Statistika", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        stats_grid = tk.Frame(summary_frame, bg=colors['section_bg'])
        stats_grid.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        # Stat boxes
        stat_items = [
            ("👥 Ukupno Klijenata", str(ukupno_klijenata), '#3498db'),
            ("📦 Ukupno Paketa", str(sum(s['count'] for s in paket_stats.values())), '#9b59b6'),
            ("💵 Ukupna Zarada", f"{ukupna_zarada:,.0f} din", '#27ae60')
        ]
        
        for i, (label, value, color) in enumerate(stat_items):
            stat_box = tk.Frame(stats_grid, bg=color, relief=tk.FLAT, bd=0)
            stat_box.grid(row=0, column=i, padx=10, pady=10, sticky='ew')
            stats_grid.columnconfigure(i, weight=1)
            
            tk.Label(stat_box, text=label, font=('Segoe UI', 10), 
                    bg=color, fg='white').pack(pady=(15, 5))
            tk.Label(stat_box, text=value, font=('Segoe UI', 20, 'bold'), 
                    bg=color, fg='white').pack(pady=(0, 15))
        
        # Detalji po paketima
        details_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        details_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(details_frame, text="📦 Detalji Po Paketima", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        # Scrollable frame
        canvas = tk.Canvas(details_frame, bg=colors['section_bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(details_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=colors['section_bg'])
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Sortiraj pakete po zaradi
        sorted_paketi = sorted(paket_stats.items(), key=lambda x: x[1]['total'], reverse=True)
        
        for naziv, stats in sorted_paketi:
            paket_card = tk.Frame(scrollable_frame, bg=colors['bg'], relief=tk.RIDGE, bd=1)
            paket_card.pack(fill=tk.X, padx=15, pady=8)
            
            # Naziv paketa
            tk.Label(paket_card, text=naziv, font=('Segoe UI', 12, 'bold'),
                    bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(10, 5))
            
            # Statistika
            stat_text = f"Prodato: {stats['count']}x  |  Zarada: {stats['total']:,.0f} din  |  Prosek: {stats['total']/stats['count']:,.0f} din"
            tk.Label(paket_card, text=stat_text, font=('Segoe UI', 10),
                    bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15, pady=(0, 10))
            
            # Progress bar (vizuelni prikaz procenat ukupne zarade)
            if ukupna_zarada > 0:
                procenat = (stats['total'] / ukupna_zarada) * 100
                bar_frame = tk.Frame(paket_card, bg=colors['section_bg'], height=25)
                bar_frame.pack(fill=tk.X, padx=15, pady=(0, 10))
                
                bar_fill = tk.Frame(bar_frame, bg='#27ae60', height=25)
                bar_fill.place(relwidth=procenat/100, relheight=1)
                
                tk.Label(bar_frame, text=f"{procenat:.1f}%", font=('Segoe UI', 9, 'bold'),
                        bg=colors['section_bg'], fg=colors['fg']).place(relx=0.5, rely=0.5, anchor='center')
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=(0, 15))
    
    def dodaj_klijenta_dijalog(self):
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novog Klijenta")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="➕ Dodaj Novog Klijenta", font=('Segoe UI', 16, 'bold'), 
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        fields = [
            ("Ime:", "ime"),
            ("Prezime:", "prezime"),
            ("Email:", "email"),
            ("Telefon:", "telefon")
        ]
        
        entries = {}
        for label_text, field_name in fields:
            label = tk.Label(form_frame, text=label_text, font=('Segoe UI', 10, 'bold'), 
                           bg=colors['bg'], fg=colors['fg'])
            label.pack(anchor=tk.W, pady=(10, 3))
            
            entry_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
            entry = tk.Entry(form_frame, font=('Segoe UI', 10), width=40, 
                           bg=entry_bg, fg=colors['fg'], insertbackground=colors['fg'])
            entry.pack(anchor=tk.W, ipady=8)
            entries[field_name] = entry
        
        entries['ime'].focus()
        
        def sačuvaj():
            ime = entries['ime'].get().strip()
            prezime = entries['prezime'].get().strip()
            email = entries['email'].get().strip()
            telefon = entries['telefon'].get().strip()
            
            if not ime or not prezime or not email:
                messagebox.showerror("Greška", "Molim unesi: Ime, Prezime i Email!")
                return
            
            id_klijenta = self.menadzer.dodaj_klijenta(ime, prezime, email, telefon)
            if id_klijenta:
                messagebox.showinfo("Uspeh", f"✓ Klijent {ime} {prezime} je uspešno dodat!")
                self.ucitaj_klijente()
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Greška pri dodavanju klijenta!")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(30, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def dodeli_paket_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Dodeli Proizvod - {ime} {prezime}")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="📦 Dodeli Proizvod", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        fields = [
            ("Naziv Proizvoda:", "naziv"),
            ("Cena (dinara):", "cena"),
            ("Datum Početka (YYYY-MM-DD):", "datum")
        ]
        
        entries = {}
        for label_text, field_name in fields:
            label = tk.Label(form_frame, text=label_text, font=('Segoe UI', 10, 'bold'), 
                           bg=colors['bg'], fg=colors['fg'])
            label.pack(anchor=tk.W, pady=(10, 3))
            
            entry_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
            entry = tk.Entry(form_frame, font=('Segoe UI', 10), width=40,
                           bg=entry_bg, fg=colors['fg'], insertbackground=colors['fg'])
            entry.pack(anchor=tk.W, ipady=8)
            entries[field_name] = entry
        
        entries['datum'].insert(0, datetime.now().strftime("%Y-%m-%d"))
        entries['naziv'].focus()
        
        def sačuvaj():
            naziv = entries['naziv'].get().strip()
            cena = entries['cena'].get().strip()
            datum = entries['datum'].get().strip()
            
            if not naziv or not cena:
                messagebox.showerror("Greška", "Molim unesi Naziv i Cenu!")
                return
            
            uspeh = self.menadzer.dodeli_paket(id_klijenta, naziv, cena, datum)
            if uspeh:
                messagebox.showinfo("Uspeh", f"✓ Proizvod je uspešno dodeljen!")
                # Osveži tabelu i panel detalja za trenutno selektovanog klijenta
                self.ucitaj_klijente(preserve_selection=True)
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Dodela paketa nije uspela. Pokušaj ponovo.")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(30, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def dodaj_belesku_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Dodaj Belešku - {ime} {prezime}")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="📝 Dodaj Belešku", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        label = tk.Label(form_frame, text="Belešku:", font=('Segoe UI', 11, 'bold'), 
                       bg=colors['bg'], fg=colors['fg'])
        label.pack(anchor=tk.W, pady=(0, 5))
        
        text_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
        beleska_text = tk.Text(form_frame, height=10, width=50, font=('Segoe UI', 10),
                              bg=text_bg, fg=colors['fg'], insertbackground=colors['fg'])
        beleska_text.pack(fill=tk.BOTH, expand=True, ipady=8)
        beleska_text.focus()
        
        def sačuvaj():
            tekst = beleska_text.get("1.0", tk.END).strip()
            
            if not tekst:
                messagebox.showerror("Greška", "Beleška ne može biti prazna!")
                return
            
            uspeh = self.menadzer.dodaj_belesku(id_klijenta, tekst)
            if uspeh:
                messagebox.showinfo("Uspeh", "✓ Beleška je uspešno dodana!")
                # Osveži tabelu i panel detalja za trenutno selektovanog klijenta
                self.ucitaj_klijente(preserve_selection=True)
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Čuvanje beleške nije uspelo. Pokušaj ponovo.")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(15, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def obrisi_klijenta_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        if messagebox.askyesno("Potvrda", f"Da li želiš da obrišeš:\n\n{ime} {prezime}?"):
            uspeh = self.menadzer.obrisi_klijenta(id_klijenta)
            if uspeh:
                messagebox.showinfo("Uspeh", "✓ Klijent je uspešno obrisan!")
                self.ucitaj_klijente(preserve_selection=False)
            else:
                messagebox.showerror("Greška", "Brisanje klijenta nije uspelo. Pokušaj ponovo.")
    
    def detaljni_pregled(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        klijent = self.menadzer.klijenti[id_klijenta]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        detail_window = tk.Toplevel(self.root)
        detail_window.title(f"Detaljni Pregled - {klijent['ime']} {klijent['prezime']}")
        detail_window.geometry("850x750")
        detail_window.transient(self.root)
        # Fade-in animation
        detail_window.attributes('-alpha', 0.0)
        self.fade_in(detail_window)
        detail_window.configure(bg=colors['bg'])
        
        # Zaglavlje sa profilnom karticom
        header = tk.Frame(detail_window, bg=colors['header'], height=120)
        header.pack(fill=tk.X)
        
        header_content = tk.Frame(header, bg=colors['header'])
        header_content.pack(expand=True, fill=tk.BOTH, padx=25, pady=20)
        
        # Avatar/Inicijali
        avatar_frame = tk.Frame(header_content, bg='#27ae60', width=70, height=70)
        avatar_frame.pack(side=tk.LEFT, padx=(0, 20))
        avatar_frame.pack_propagate(False)
        
        inicijali = f"{klijent['ime'][0]}{klijent['prezime'][0]}".upper()
        tk.Label(avatar_frame, text=inicijali, font=('Segoe UI', 24, 'bold'),
                bg='#27ae60', fg='white').place(relx=0.5, rely=0.5, anchor='center')
        
        # Info pored avatara
        info_header = tk.Frame(header_content, bg=colors['header'])
        info_header.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(info_header, text=f"{klijent['ime']} {klijent['prezime']}", 
                font=('Segoe UI', 20, 'bold'), bg=colors['header'], fg='white').pack(anchor=tk.W)
        tk.Label(info_header, text=f"ID: {id_klijenta}", 
                font=('Segoe UI', 10), bg=colors['header'], fg='#95a5a6').pack(anchor=tk.W, pady=(5, 0))
        
        # Sadržaj
        content = tk.Frame(detail_window, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=20)
        
        # Kontakt informacije - moderan dizajn
        contact_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        contact_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(contact_frame, text="📞 Kontakt Informacije", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=20, pady=(15, 10))
        
        # Grid layout za kontakt info
        contact_grid = tk.Frame(contact_frame, bg=colors['section_bg'])
        contact_grid.pack(fill=tk.X, padx=20, pady=(0, 15))
        
        # Email
        email_box = tk.Frame(contact_grid, bg=colors['bg'], relief=tk.RIDGE, bd=1)
        email_box.grid(row=0, column=0, sticky='ew', padx=(0, 10), pady=5)
        tk.Label(email_box, text="📧 Email", font=('Segoe UI', 9), 
                bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=10, pady=(8, 2))
        tk.Label(email_box, text=klijent['email'], font=('Segoe UI', 11, 'bold'), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=10, pady=(0, 8))
        
        # Telefon
        phone_box = tk.Frame(contact_grid, bg=colors['bg'], relief=tk.RIDGE, bd=1)
        phone_box.grid(row=0, column=1, sticky='ew', padx=(10, 0), pady=5)
        tk.Label(phone_box, text="📱 Telefon", font=('Segoe UI', 9), 
                bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=10, pady=(8, 2))
        tk.Label(phone_box, text=klijent['telefon'], font=('Segoe UI', 11, 'bold'), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=10, pady=(0, 8))
        
        contact_grid.columnconfigure(0, weight=1)
        contact_grid.columnconfigure(1, weight=1)
        
        # Paketi - modernizovan prikaz
        paketi_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        paketi_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        paketi_header = tk.Frame(paketi_frame, bg=colors['section_bg'])
        paketi_header.pack(fill=tk.X, padx=20, pady=(15, 10))
        
        tk.Label(paketi_header, text="📦 Dodeljeni Paketi", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT)
        
        if klijent['paketi']:
            tk.Label(paketi_header, text=f"{len(klijent['paketi'])} paket(a)", 
                    font=('Segoe UI', 10), bg='#27ae60', fg='white',
                    padx=12, pady=4).pack(side=tk.LEFT, padx=(10, 0))
        
        # Scrollable container za pakete
        paketi_canvas = tk.Canvas(paketi_frame, bg=colors['section_bg'], highlightthickness=0, height=180)
        paketi_scrollbar = ttk.Scrollbar(paketi_frame, orient="vertical", command=paketi_canvas.yview)
        paketi_container = tk.Frame(paketi_canvas, bg=colors['section_bg'])
        
        paketi_container.bind("<Configure>", lambda e: paketi_canvas.configure(scrollregion=paketi_canvas.bbox("all")))
        paketi_canvas.create_window((0, 0), window=paketi_container, anchor="nw")
        paketi_canvas.configure(yscrollcommand=paketi_scrollbar.set)
        
        if klijent['paketi']:
            for i, paket in enumerate(klijent['paketi'], 1):
                paket_card = tk.Frame(paketi_container, bg=colors['bg'], relief=tk.RIDGE, bd=1)
                paket_card.pack(fill=tk.X, padx=20, pady=5)
                
                # Naziv paketa
                tk.Label(paket_card, text=f"{i}. {paket['naziv']}", 
                        font=('Segoe UI', 11, 'bold'), bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(10, 5))
                
                # Detalji u grid-u
                details = tk.Frame(paket_card, bg=colors['bg'])
                details.pack(fill=tk.X, padx=15, pady=(0, 10))
                
                tk.Label(details, text=f"💰 {paket['cena']} din", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT, padx=(0, 15))
                tk.Label(details, text=f"📅 {paket['datum_pocetka']}", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT, padx=(0, 15))
                tk.Label(details, text=f"⏰ {paket['datum_dodele']}", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT)
        else:
            tk.Label(paketi_container, text="Nema dodeljenih paketa", font=('Segoe UI', 10, 'italic'),
                    bg=colors['section_bg'], fg=colors['fg_secondary']).pack(padx=20, pady=20)
        
        paketi_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        paketi_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Beleške - modernizovan prikaz
        beleske_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        beleske_frame.pack(fill=tk.BOTH, expand=True)
        
        beleske_header = tk.Frame(beleske_frame, bg=colors['section_bg'])
        beleske_header.pack(fill=tk.X, padx=20, pady=(15, 10))
        
        tk.Label(beleske_header, text="📝 Beleške", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT)
        
        if klijent['beleske']:
            tk.Label(beleske_header, text=f"{len(klijent['beleske'])} beleška", 
                    font=('Segoe UI', 10), bg='#f39c12', fg='white',
                    padx=12, pady=4).pack(side=tk.LEFT, padx=(10, 0))
        
        # Scrollable container za beleške
        beleske_canvas = tk.Canvas(beleske_frame, bg=colors['section_bg'], highlightthickness=0, height=180)
        beleske_scrollbar = ttk.Scrollbar(beleske_frame, orient="vertical", command=beleske_canvas.yview)
        beleske_container = tk.Frame(beleske_canvas, bg=colors['section_bg'])
        
        beleske_container.bind("<Configure>", lambda e: beleske_canvas.configure(scrollregion=beleske_canvas.bbox("all")))
        beleske_canvas.create_window((0, 0), window=beleske_container, anchor="nw")
        beleske_canvas.configure(yscrollcommand=beleske_scrollbar.set)
        
        if klijent['beleske']:
            for idx, beleska in enumerate(klijent['beleske']):
                prikazni_broj = idx + 1
                beleska_card = tk.Frame(beleske_container, bg=colors['bg'], relief=tk.RIDGE, bd=1)
                beleska_card.pack(fill=tk.X, padx=20, pady=5)

                # Right-click menu binding na celu karticu
                beleska_card.bind('<Button-3>', lambda e, i=idx: self.beleska_right_click_menu(e, id_klijenta, i))

                # Header beleške sa datumom
                beleska_header = tk.Frame(beleska_card, bg=colors['header'])
                beleska_header.pack(fill=tk.X)
                beleska_header.bind('<Button-3>', lambda e, i=idx: self.beleska_right_click_menu(e, id_klijenta, i))

                tk.Label(beleska_header, text=f"Beleška #{prikazni_broj}", font=('Segoe UI', 9, 'bold'),
                        bg=colors['header'], fg='white').pack(side=tk.LEFT, padx=15, pady=8)
                tk.Label(beleska_header, text=beleska['datum'], font=('Segoe UI', 8),
                        bg=colors['header'], fg='#95a5a6').pack(side=tk.RIGHT, padx=15, pady=8)

                # Tekst beleške
                tekst_label = tk.Label(beleska_card, text=beleska['tekst'], font=('Segoe UI', 10),
                        bg=colors['bg'], fg=colors['fg'], wraplength=750, justify=tk.LEFT)
                tekst_label.pack(anchor=tk.W, padx=15, pady=12)
                tekst_label.bind('<Button-3>', lambda e, i=idx: self.beleska_right_click_menu(e, id_klijenta, i))
        else:
            tk.Label(beleske_container, text="Nema beleški", font=('Segoe UI', 10, 'italic'),
                    bg=colors['section_bg'], fg=colors['fg_secondary']).pack(padx=20, pady=20)
        
        beleske_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        beleske_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Dodaj dugme za dodavanje beleške
        btn_frame = tk.Frame(detail_window, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=25, pady=(10, 20))
        
        def dodaj_belezku_lokalno():
            detail_window.destroy()
            # Prvo selektuj klijenta u tree-u
            for item in self.tree.get_children():
                if str(self.tree.item(item)['values'][0]).strip() == id_klijenta:
                    self.tree.selection_set(item)
                    self.tree.focus(item)
                    break
            self.dodaj_belesku_dijalog()
        
        add_note_btn = tk.Button(btn_frame, text="📝 Dodaj Novu Belešku", 
                                command=dodaj_belezku_lokalno,
                                font=('Segoe UI', 11, 'bold'), bg='#f39c12', fg='white',
                                padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_note_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_note_btn, '#f39c12', '#f5b041')
        
        close_btn = tk.Button(btn_frame, text="✖ Zatvori", 
                             command=detail_window.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(close_btn, '#95a5a6', '#b4bcc2')

    def beleska_right_click_menu(self, event, id_klijenta, indeks_beleske):
        colors = self.dark_colors if self.dark_mode else self.light_colors
        menu = tk.Menu(self.root, tearoff=0,
                       bg=colors['section_bg'], fg=colors['fg'],
                       activebackground='#f39c12', activeforeground='white',
                       font=('Segoe UI', 11), relief=tk.FLAT, bd=2)

        # Dodaj novu belešku (otvara već postojeći dijalog)
        menu.add_command(label='   ➕  Dodaj Belešku   ',
                         command=lambda: self.dodaj_belesku_dijalog(), compound='left')
        # Izmeni ovu belešku
        menu.add_command(label='   ✏️  Izmeni Belešku   ',
                         command=lambda: self.izmeni_belesku_dijalog(id_klijenta, indeks_beleske), compound='left')
        # Obriši ovu belešku
        menu.add_command(label='   🗑️  Obriši Belešku   ',
                         command=lambda: self.obrisi_belesku_akcija(id_klijenta, indeks_beleske), compound='left')

        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def izmeni_belesku_dijalog(self, id_klijenta, indeks_beleske):
        # Učitaj trenutni tekst
        klijent = self.menadzer.klijenti.get(id_klijenta, {})
        beleške = klijent.get('beleske', [])
        if indeks_beleske < 0 or indeks_beleske >= len(beleške):
            return
        trenutni = beleške[indeks_beleske]['tekst']

        colors = self.dark_colors if self.dark_mode else self.light_colors
        dialog = tk.Toplevel(self.root)
        dialog.title("Izmeni Belešku")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(bg=colors['bg'])

        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="✏️ Izmeni Belešku", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)

        form = tk.Frame(dialog, bg=colors['bg'])
        form.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        text_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
        text = tk.Text(form, height=10, font=('Segoe UI', 10), bg=text_bg, fg=colors['fg'], insertbackground=colors['fg'])
        text.pack(fill=tk.BOTH, expand=True)
        text.insert('1.0', trenutni)

        def sacuvaj():
            novi = text.get('1.0', tk.END).strip()
            if not novi:
                messagebox.showerror("Greška", "Beleška ne može biti prazna!")
                return
            if self.menadzer.izmeni_belesku(id_klijenta, indeks_beleske, novi):
                messagebox.showinfo("Uspeh", "Beleška je izmenjena.")
                dialog.destroy()
                # Osveži tabelu i ponovo otvori detaljni pregled
                self.ucitaj_klijente(preserve_selection=True)
                self.detaljni_pregled()
            else:
                messagebox.showerror("Greška", "Izmena beleške nije uspela.")

        btns = tk.Frame(form, bg=colors['bg'])
        btns.pack(fill=tk.X, pady=(10, 0))
        save_btn = tk.Button(btns, text='✓ Sačuvaj', command=sacuvaj,
                             font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white', padx=20, pady=8, border=0, relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        cancel_btn = tk.Button(btns, text='✕ Otkaži', command=dialog.destroy,
                               font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white', padx=20, pady=8, border=0, relief=tk.FLAT)
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')

    def obrisi_belesku_akcija(self, id_klijenta, indeks_beleske):
        if not messagebox.askyesno("Potvrda", "Da li želiš da obrišeš ovu belešku?"):
            return
        if self.menadzer.obrisi_belesku(id_klijenta, indeks_beleske):
            messagebox.showinfo("Uspeh", "Beleška je obrisana.")
            # Osveži tabelu i ponovo otvori detaljni pregled
            self.ucitaj_klijente(preserve_selection=True)
            self.detaljni_pregled()
        else:
            messagebox.showerror("Greška", "Brisanje beleške nije uspelo.")

if __name__ == "__main__":
    root = tk.Tk()
    app = GUIApp(root)
    root.mainloop()
