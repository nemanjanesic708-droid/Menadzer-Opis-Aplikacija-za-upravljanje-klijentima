# Menadžer Klijenata

Aplikacija za upravljanje klijentima, paketima i praćenje prihoda.

## Funkcionalnosti

- 📧 **Outreach** - Praćenje komunikacije sa klijentima
- 📅 **Schedule** - Kalendar zadataka
- 📋 **Klijenti** - Upravljanje bazom klijenata i paketima
- 📊 **Overview** - Statistika i analiza prihoda

## Instalacija

```bash
pip install tkinter
```

## Pokretanje

```bash
python menadzer_app.py
```

## Karakteristike

- Kreiranje naloga i autentifikacija korisnika
- Dodavanje i upravljanje klijentima
- Dodela paketa/proizvoda klijentima
- Praćenje outreach komunikacije
- Raspored zadataka
- Detaljni pregled prihoda po proizvodima (lifetime, godišnji, mesečni)
- Dark mode tema
- Auto logout nakon neaktivnosti
