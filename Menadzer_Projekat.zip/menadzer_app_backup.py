
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
import hashlib
import time
from menadzer import MenazerKlijenata

# Uvek koristi JSON fajl u istom folderu kao skripta
PODACI_FAJL = os.path.join(os.path.dirname(__file__), "klijenti_podaci.json")
KORISNICI_FAJL = os.path.join(os.path.dirname(__file__), "korisnici.json")

class UserManager:
    def __init__(self):
        self.korisnici = self.ucitaj_korisnike()
    
    def ucitaj_korisnike(self):
        if os.path.exists(KORISNICI_FAJL):
            try:
                with open(KORISNICI_FAJL, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def sacuvaj_korisnike(self):
        try:
            with open(KORISNICI_FAJL, 'w', encoding='utf-8') as f:
                json.dump(self.korisnici, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"Gre\u0161ka pri \u010duvanju korisnika: {e}")
            return False
    
    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()
    
    def registruj_korisnika(self, username, password):
        if username in self.korisnici:
            return False, "Korisni\u010dko ime ve\u0107 postoji!"
        
        self.korisnici[username] = {
            "password": self.hash_password(password),
            "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.sacuvaj_korisnike()
        return True, "Nalog uspe\u0161no kreiran!"
    
    def autentifikuj(self, username, password):
        if username not in self.korisnici:
            return False, "Korisnik ne postoji!"
        
        if self.korisnici[username]["password"] == self.hash_password(password):
            return True, "Uspe\u0161na prijava!"
        return False, "Pogre\u0161na lozinka!"

class MenazerKlijenata:
    def __init__(self):
        self.klijenti = self.ucitaj_podatke()
    
    def ucitaj_podatke(self):
        if os.path.exists(PODACI_FAJL):
            try:
                with open(PODACI_FAJL, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data if isinstance(data, dict) else {}
            except:
                return {}
        return {}
    
    def sacuvaj_podatke(self):
        try:
            with open(PODACI_FAJL, 'w', encoding='utf-8') as f:
                json.dump(self.klijenti, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"Greška pri čuvanju: {e}")
            return False
    
    def dodaj_klijenta(self, ime, prezime, email, telefon):
        try:
            max_id = 0
            for k_id in self.klijenti.keys():
                try:
                    if int(k_id) > max_id:
                        max_id = int(k_id)
                except:
                    pass
            
            id_klijenta = str(max_id + 1)
            self.klijenti[id_klijenta] = {
                "ime": ime,
                "prezime": prezime,
                "email": email,
                "telefon": telefon,
                "paketi": [],
                "beleske": []
            }
            self.sacuvaj_podatke()
            return id_klijenta
        except Exception as e:
            print(f"Greška pri dodavanju: {e}")
            return None
    
    def dodeli_paket(self, id_klijenta, naziv_paketa, cena, datum_pocetka):
        if id_klijenta not in self.klijenti:
            return False
        
        paket = {
            "naziv": naziv_paketa,
            "cena": cena,
            "datum_pocetka": datum_pocetka,
            "datum_dodele": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.klijenti[id_klijenta]["paketi"].append(paket)
        self.sacuvaj_podatke()
        return True
    
    def dodaj_belesku(self, id_klijenta, tekst_beleske):
        if id_klijenta not in self.klijenti:
            return False
        
        beleska = {
            "tekst": tekst_beleske,
            "datum": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        self.klijenti[id_klijenta]["beleske"].append(beleska)
        self.sacuvaj_podatke()
        return True
    
    def obrisi_klijenta(self, id_klijenta):
        if id_klijenta in self.klijenti:
            del self.klijenti[id_klijenta]
            self.sacuvaj_podatke()
            return True
        return False

class GUIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Menad\u017eer Klijenata - Login")
        self.root.geometry("1200x700")
        self.root.configure(bg='#f5f6fa')
        
        self.user_manager = UserManager()
        self.menadzer = MenazerKlijenata()
        self.current_user = None
        self.inactivity_timeout = 15 * 60  # 15 minuta u sekundama
        self.last_activity = time.time()
        self.timer_running = False
        
        # Dark mode state
        self.dark_mode = False
        self.light_colors = {
            'bg': '#f5f6fa',
            'header': '#2c3e50',
            'text': '#2c3e50',
            'button_bg': '#f5f6fa',
            'section_bg': 'white',
            'fg': '#2c3e50',
            'fg_secondary': '#7f8c8d'
        }
        self.dark_colors = {
            'bg': '#1a1a2e',
            'header': '#16213e',
            'text': '#eaeaea',
            'button_bg': '#0f3460',
            'section_bg': '#16213e',
            'fg': '#eaeaea',
            'fg_secondary': '#95a5a6'
        }
        
        # Moderan stil
        self.setup_style()
        
        # Prikaži login ekran
        self.show_login_screen()
    
    def show_login_screen(self):
        """Prikazuje login ekran"""
        # Očisti prozor
        for widget in self.root.winfo_children():
            widget.destroy()
        
        self.root.title("Menadžer Klijenata - Prijava")
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Root background
        self.root.configure(bg=colors['bg'])
        
        # Dark mode toggle dugme u gornjem desnom uglu
        dark_toggle_btn = tk.Button(self.root, text="🌙" if not self.dark_mode else "☀️",
                                    command=lambda: self.toggle_dark_and_refresh_login(),
                                    font=('Segoe UI', 16), bg=colors['header'], fg='white',
                                    padx=15, pady=8, border=0, cursor='hand2', relief=tk.FLAT)
        dark_toggle_btn.place(relx=1.0, rely=0, anchor='ne', x=-20, y=20)
        
        # Centralni frame
        login_frame = tk.Frame(self.root, bg=colors['bg'])
        login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        # Logo/Naslov
        tk.Label(login_frame, text="👥 MENADŽER KLIJENATA", font=('Segoe UI', 28, 'bold'),
                bg=colors['bg'], fg=colors['fg']).pack(pady=(0, 10))
        
        tk.Label(login_frame, text="Prijavite se na svoj nalog", font=('Segoe UI', 12),
                bg=colors['bg'], fg=colors['fg_secondary']).pack(pady=(0, 30))
        
        # Login forma
        form_frame = tk.Frame(login_frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        form_frame.pack(padx=40, pady=20)
        
        tk.Label(form_frame, text="", bg=colors['section_bg']).pack(pady=10)  # Spacing
        
        tk.Label(form_frame, text="Korisničko ime:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        username_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, relief=tk.FLAT, bd=2)
        username_entry.pack(padx=30, pady=(5, 15), ipady=8)
        username_entry.focus()
        
        tk.Label(form_frame, text="Lozinka:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        password_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, show='●', relief=tk.FLAT, bd=2)
        password_entry.pack(padx=30, pady=(5, 20), ipady=8)
        
        def do_login():
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            
            if not username or not password:
                messagebox.showerror("Greška", "Unesite korisničko ime i lozinku!")
                return
            
            success, message = self.user_manager.autentifikuj(username, password)
            if success:
                self.current_user = username
                self.show_main_app()
            else:
                messagebox.showerror("Greška", message)
        
        def show_register():
            self.show_register_screen()
        
        # Enter key za login
        password_entry.bind('<Return>', lambda e: do_login())
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['section_bg'])
        btn_frame.pack(pady=(0, 20), padx=30)
        
        login_btn = tk.Button(btn_frame, text="✓ Prijavi se", command=do_login,
                             font=('Segoe UI', 12, 'bold'), bg='#27ae60', fg='white',
                             padx=30, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        login_btn.pack(fill=tk.X, pady=(0, 10))
        self.add_button_hover(login_btn, '#27ae60', '#2ecc71')
        
        register_btn = tk.Button(btn_frame, text="➕ Napravi nalog", command=show_register,
                                font=('Segoe UI', 11), bg='#3498db', fg='white',
                                padx=30, pady=8, border=0, cursor='hand2', relief=tk.FLAT)
        register_btn.pack(fill=tk.X)
        self.add_button_hover(register_btn, '#3498db', '#5dade2')
    
    def show_register_screen(self):
        """Prikazuje ekran za registraciju"""
        # Očisti prozor
        for widget in self.root.winfo_children():
            widget.destroy()
        
        self.root.title("Menadžer Klijenata - Registracija")
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        self.root.configure(bg=colors['bg'])
        
        # Dark mode toggle dugme
        dark_toggle_btn = tk.Button(self.root, text="🌙" if not self.dark_mode else "☀️",
                                    command=lambda: self.toggle_dark_and_refresh_register(),
                                    font=('Segoe UI', 16), bg=colors['header'], fg='white',
                                    padx=15, pady=8, border=0, cursor='hand2', relief=tk.FLAT)
        dark_toggle_btn.place(relx=1.0, rely=0, anchor='ne', x=-20, y=20)
        
        # Centralni frame
        register_frame = tk.Frame(self.root, bg=colors['bg'])
        register_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
        
        # Naslov
        tk.Label(register_frame, text="➕ KREIRANJE NALOGA", font=('Segoe UI', 24, 'bold'),
                bg=colors['bg'], fg=colors['fg']).pack(pady=(0, 10))
        
        tk.Label(register_frame, text="Napravite svoj menadžerski nalog", font=('Segoe UI', 11),
                bg=colors['bg'], fg=colors['fg_secondary']).pack(pady=(0, 25))
        
        # Forma
        form_frame = tk.Frame(register_frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        form_frame.pack(padx=40, pady=20)
        
        tk.Label(form_frame, text="", bg=colors['section_bg']).pack(pady=10)
        
        tk.Label(form_frame, text="Korisničko ime:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        username_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, relief=tk.FLAT, bd=2)
        username_entry.pack(padx=30, pady=(5, 15), ipady=8)
        username_entry.focus()
        
        tk.Label(form_frame, text="Lozinka:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        password_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, show='●', relief=tk.FLAT, bd=2)
        password_entry.pack(padx=30, pady=(5, 15), ipady=8)
        
        tk.Label(form_frame, text="Potvrdi lozinku:", font=('Segoe UI', 11, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=30)
        confirm_entry = tk.Entry(form_frame, font=('Segoe UI', 12), width=30, show='●', relief=tk.FLAT, bd=2)
        confirm_entry.pack(padx=30, pady=(5, 20), ipady=8)
        
        def do_register():
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            confirm = confirm_entry.get().strip()
            
            if not username or not password:
                messagebox.showerror("Greška", "Unesite korisničko ime i lozinku!")
                return
            
            if len(password) < 4:
                messagebox.showerror("Greška", "Lozinka mora biti bar 4 karaktera!")
                return
            
            if password != confirm:
                messagebox.showerror("Greška", "Lozinke se ne poklapaju!")
                return
            
            success, message = self.user_manager.registruj_korisnika(username, password)
            if success:
                messagebox.showinfo("Uspeh", message)
                self.show_login_screen()
            else:
                messagebox.showerror("Greška", message)
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['section_bg'])
        btn_frame.pack(pady=(0, 20), padx=30)
        
        register_btn = tk.Button(btn_frame, text="✓ Kreiraj nalog", command=do_register,
                                font=('Segoe UI', 12, 'bold'), bg='#27ae60', fg='white',
                                padx=30, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        register_btn.pack(fill=tk.X, pady=(0, 10))
        self.add_button_hover(register_btn, '#27ae60', '#2ecc71')
        
        back_btn = tk.Button(btn_frame, text="← Nazad na prijavu", command=self.show_login_screen,
                            font=('Segoe UI', 10), bg='#95a5a6', fg='white',
                            padx=30, pady=8, border=0, cursor='hand2', relief=tk.FLAT)
        back_btn.pack(fill=tk.X)
        self.add_button_hover(back_btn, '#95a5a6', '#a6b4b6')
    
    def toggle_dark_and_refresh_login(self):
        """Toggle dark mode i refresh login screen"""
        self.toggle_dark_mode()
        self.show_login_screen()
    
    def toggle_dark_and_refresh_register(self):
        """Toggle dark mode i refresh register screen"""
        self.toggle_dark_mode()
        self.show_register_screen()
    
    def show_main_app(self):
        """Prikazuje glavni ekran aplikacije nakon login-a"""
        # Očisti prozor
        for widget in self.root.winfo_children():
            widget.destroy()
        
        self.root.title(f"Menadžer Klijenata - {self.current_user}")
        
        # Glavni frame
        self.main_frame = ttk.Frame(self.root, style='Main.TFrame')
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=0, pady=0)
        
        # Header
        self.setup_header()
        
        # Kreiraj notebook sa tabovima
        self.setup_notebook()
        
        # Primeni stilove
        self.setup_style()
        
        # Pokreni inactivity timer
        self.start_inactivity_timer()
        
        # Bind aktivnosti
        self.root.bind_all('<Any-KeyPress>', self.reset_timer)
        self.root.bind_all('<Any-Button>', self.reset_timer)
        self.root.bind_all('<Motion>', self.reset_timer)
    
    def setup_notebook(self):
        """Kreira notebook sa tabovima"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Notebook container sa marginama
        notebook_frame = tk.Frame(self.main_frame, bg=colors['bg'])
        notebook_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(5, 15))
        
        self.notebook = ttk.Notebook(notebook_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Tab 1: Menadžment Klijenata (imenik)
        self.klijenti_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.klijenti_tab, text='  📋  Klijenati  ')
        self.setup_klijenti_tab()
        
        # Tab 2: Overview
        self.overview_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.overview_tab, text='  📊  Overview  ')
        self.setup_overview_tab()
        
        # Tab 3: Schedule
        self.schedule_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.schedule_tab, text='  📅  Schedule  ')
        self.setup_schedule_tab()
        
        # Tab 4: Outreach
        self.outreach_tab = ttk.Frame(self.notebook, style='Main.TFrame')
        self.notebook.add(self.outreach_tab, text='  📧  Outreach  ')
        self.setup_outreach_tab()
    
    def start_inactivity_timer(self):
        """Pokreće tajmer za auto logout"""
        self.timer_running = True
        self.last_activity = time.time()
        self.check_inactivity()
    
    def check_inactivity(self):
        """Proverava neaktivnost i logout"""
        if not self.timer_running:
            return
        
        if time.time() - self.last_activity > self.inactivity_timeout:
            self.logout("Auto logout - neaktivnost")
            return
        
        self.root.after(1000, self.check_inactivity)  # Proveri svake sekunde
    
    def reset_timer(self, event=None):
        """Resetuje tajmer neaktivnosti"""
        self.last_activity = time.time()
    
    def logout(self, reason=""):
        """Odjavljuje korisnika"""
        self.timer_running = False
        if reason:
            messagebox.showinfo("Odjava", reason)
        self.current_user = None
        self.show_login_screen()
    
    def setup_style(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Modern color scheme
        style.configure('Title.TLabel', font=('Segoe UI', 24, 'bold'), background=colors['header'], foreground='white')
        style.configure('Header.TFrame', background=colors['header'])
        style.configure('Main.TFrame', background=colors['bg'])
        style.configure('TLabel', background=colors['bg'], foreground=colors['text'], font=('Segoe UI', 10))
        style.configure('TEntry', font=('Segoe UI', 10), padding=8)
        
        # NOTEBOOK/TAB STYLING - Veliki i lepši tabovi
        tab_bg = '#2c3e50' if not self.dark_mode else '#16213e'
        tab_fg = 'white'
        tab_selected_bg = '#3498db' if not self.dark_mode else '#1e5f8f'
        
        style.configure('TNotebook', background=colors['bg'], borderwidth=0, tabmargins=[2, 5, 2, 0])
        style.configure('TNotebook.Tab', 
                       font=('Segoe UI', 12, 'bold'),
                       padding=[25, 15],  # Veći padding za veće tabove
                       background=tab_bg,
                       foreground=tab_fg,
                       borderwidth=0)
        style.map('TNotebook.Tab',
                 background=[('selected', tab_selected_bg), ('active', '#34495e')],
                 foreground=[('selected', 'white'), ('active', 'white')],
                 expand=[('selected', [1, 1, 1, 0])])  # Selected tab je malo veći
        
        # Light mode Treeview
        style.configure('Treeview', font=('Segoe UI', 10), rowheight=35, background='white', 
                       foreground='#2c3e50', fieldbackground='white')
        style.configure('Treeview.Heading', font=('Segoe UI', 11, 'bold'), background='#1c2833', foreground='white')
        style.map('Treeview.Heading', background=[('active', '#17202a')])
        style.map('Treeview', background=[('selected', '#2874a6')], foreground=[('selected', 'white')])
        
        # Dark mode Treeview
        style.configure('Dark.Treeview', font=('Segoe UI', 10), rowheight=35, 
                       background='#0f3460', foreground='#eaeaea', fieldbackground='#0f3460')
        style.configure('Dark.Treeview.Heading', font=('Segoe UI', 11, 'bold'), 
                       background='#16213e', foreground='white')
        style.map('Dark.Treeview.Heading', background=[('active', '#1a2a4a')])
        style.map('Dark.Treeview', background=[('selected', '#1e5f8f')], foreground=[('selected', 'white')])
    
    def setup_header(self):
        self.header_frame = ttk.Frame(self.main_frame, style='Header.TFrame')
        self.header_frame.pack(fill=tk.X, padx=0, pady=0)
        
        title_frame = ttk.Frame(self.header_frame, style='Header.TFrame')
        title_frame.pack(fill=tk.X, padx=30, pady=20)
        
        title_label = ttk.Label(title_frame, text="👥 MENADŽER KLIJENATA", style='Title.TLabel', 
                               background='#2c3e50', foreground='white', font=('Segoe UI', 24, 'bold'))
        title_label.pack(side=tk.LEFT, anchor=tk.W)
        
        # Right side controls
        controls_frame = tk.Frame(title_frame, bg='#2c3e50')
        controls_frame.pack(side=tk.RIGHT, anchor=tk.E)
        
        # User label
        tk.Label(controls_frame, text=f"👤 {self.current_user}", font=('Segoe UI', 10, 'bold'),
                bg='#2c3e50', fg='#ecf0f1').pack(side=tk.LEFT, padx=(0, 15))
        
        # Settings button (gear icon)
        settings_btn = tk.Button(controls_frame, text="⚙️", command=self.show_settings,
                                font=('Segoe UI', 16), bg='#34495e', fg='white',
                                padx=10, pady=2, border=0, cursor='hand2', relief=tk.FLAT)
        settings_btn.pack(side=tk.LEFT, padx=(0, 10))
        self.add_button_hover(settings_btn, '#34495e', '#4a5f7f')
        
        # Logout button
        logout_btn = tk.Button(controls_frame, text="🚪 Odjava", command=lambda: self.logout(""),
                              font=('Segoe UI', 9, 'bold'), bg='#e74c3c', fg='white',
                              padx=12, pady=5, border=0, cursor='hand2', relief=tk.FLAT)
        logout_btn.pack(side=tk.LEFT)
        self.add_button_hover(logout_btn, '#e74c3c', '#ec7063')
    
    def setup_klijenti_tab(self):
        """Setup za Menadžment Klijenata tab - imenik za ponovnu saradnju"""
        content_frame = ttk.Frame(self.klijenti_tab, style='Main.TFrame')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=15)
        
        # Search bar
        colors = self.dark_colors if self.dark_mode else self.light_colors
        search_frame = tk.Frame(content_frame, bg=colors['bg'])
        search_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(search_frame, text="🔍", font=('Segoe UI', 16), bg=colors['bg'], fg=colors['fg']).pack(side=tk.LEFT, padx=(0, 5))
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.pretrazi_klijente())
        
        # Entry sa dinamičkim bojama
        search_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
        search_fg = colors['fg']
        search_entry = tk.Entry(search_frame, textvariable=self.search_var, font=('Segoe UI', 11), 
                               relief=tk.FLAT, bd=2, width=40, bg=search_bg, fg=search_fg, 
                               insertbackground=search_fg)
        search_entry.pack(side=tk.LEFT, ipady=8, padx=(0, 15))
        
        tk.Label(search_frame, text="Pretraži po imenu, prezimenu, email-u ili telefonu", 
                font=('Segoe UI', 9), bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT)
        
        # Dugmići
        button_frame = ttk.Frame(content_frame, style='Main.TFrame')
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        buttons_data = [
            ("➕ Dodaj Klijenta", self.dodaj_klijenta_dijalog, '#27ae60'),
            ("📦 Dodeli Proizvod", self.dodeli_paket_dijalog, '#3498db'),
            ("🗑️ Obriši", self.obrisi_klijenta_dijalog, '#e74c3c'),
            ("🔄 Osveži", self.ucitaj_klijente, '#34495e'),
        ]
        
        for text, command, color in buttons_data:
            btn = tk.Button(button_frame, text=text, command=command, 
                           font=('Segoe UI', 11, 'bold'), 
                           bg=color, fg='white', 
                           padx=20, pady=12, 
                           border=0, cursor='hand2',
                           relief=tk.FLAT,
                           activebackground=self.darker_color(color),
                           activeforeground='white')
            btn.pack(side=tk.LEFT, padx=8)
            # Add hover animation
            self.add_button_hover(btn, color, self.lighter_color(color))
        
        # Tabela
        tree_frame = ttk.Frame(content_frame, style='Main.TFrame')
        tree_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        scrollbar = ttk.Scrollbar(tree_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Koristi odgovarajući stil na osnovu dark_mode
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.tree = ttk.Treeview(tree_frame, 
                                columns=('ID', 'Ime', 'Prezime', 'Email', 'Telefon', 'Paketi', 'Beleške'),
                                height=20, yscrollcommand=scrollbar.set, style=tree_style)
        scrollbar.config(command=self.tree.yview)
        
        self.tree.column('#0', width=0, stretch=tk.NO)
        self.tree.column('ID', anchor=tk.CENTER, width=50)
        self.tree.column('Ime', anchor=tk.W, width=130)
        self.tree.column('Prezime', anchor=tk.W, width=130)
        self.tree.column('Email', anchor=tk.W, width=200)
        self.tree.column('Telefon', anchor=tk.W, width=120)
        self.tree.column('Paketi', anchor=tk.CENTER, width=80)
        self.tree.column('Beleške', anchor=tk.CENTER, width=80)
        
        for col in self.tree['columns']:
            self.tree.heading(col, text=col)
        
        self.tree.pack(fill=tk.BOTH, expand=True)

        # Dupli klik otvara detaljni prozor
        self.tree.bind('<Double-Button-1>', lambda e: self.detaljni_pregled())
        
        # Dugme za pregled
        detail_btn = tk.Button(content_frame, text="👁️ Detaljni Pregled Klijenta", 
                              command=self.detaljni_pregled,
                              font=('Segoe UI', 10, 'bold'),
                              bg='#9b59b6', fg='white',
                              padx=15, pady=10,
                              border=0, cursor='hand2',
                              activebackground='#8e44ad')
        detail_btn.pack(side=tk.LEFT, padx=5)
        
        # Učitaj klijente
        self.ucitaj_klijente()
    
    def setup_overview_tab(self):
        """Setup za Overview tab - statistike i grafikoni"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.overview_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Poziv postojeće overview funkcionalnosti ali integrisano u tab
        self.load_overview_content(content)
    
    def load_overview_content(self, parent_frame):
        """Učitava overview statistike u dati frame"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Izračunaj statistike
        paket_stats = {}
        ukupno_klijenata = len(self.menadzer.klijenti)
        ukupna_zarada = 0
        
        for klijent in self.menadzer.klijenti.values():
            for paket in klijent['paketi']:
                naziv = paket['naziv']
                cena = float(paket['cena'])
                
                if naziv not in paket_stats:
                    paket_stats[naziv] = {'count': 0, 'total': 0}
                
                paket_stats[naziv]['count'] += 1
                paket_stats[naziv]['total'] += cena
                ukupna_zarada += cena
        
        # Summary section
        summary_frame = tk.Frame(parent_frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        summary_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(summary_frame, text="💰 Ukupna Statistika", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        stats_grid = tk.Frame(summary_frame, bg=colors['section_bg'])
        stats_grid.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        # Stat boxes
        stat_items = [
            ("👥 Ukupno Klijenata", str(ukupno_klijenata), '#3498db'),
            ("📦 Ukupno Paketa", str(sum(s['count'] for s in paket_stats.values())), '#9b59b6'),
            ("💵 Ukupna Zarada", f"{ukupna_zarada:,.0f} din", '#27ae60')
        ]
        
        for i, (label, value, color) in enumerate(stat_items):
            stat_box = tk.Frame(stats_grid, bg=color, relief=tk.FLAT, bd=0)
            stat_box.grid(row=0, column=i, padx=10, pady=10, sticky='ew')
            stats_grid.columnconfigure(i, weight=1)
            
            tk.Label(stat_box, text=label, font=('Segoe UI', 10), 
                    bg=color, fg='white').pack(pady=(15, 5))
            tk.Label(stat_box, text=value, font=('Segoe UI', 20, 'bold'), 
                    bg=color, fg='white').pack(pady=(0, 15))
        
        # Detalji po paketima
        details_frame = tk.Frame(parent_frame, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        details_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(details_frame, text="📦 Detalji Po Paketima", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        # Scrollable frame
        canvas = tk.Canvas(details_frame, bg=colors['section_bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(details_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=colors['section_bg'])
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Sortiraj pakete po zaradi
        sorted_paketi = sorted(paket_stats.items(), key=lambda x: x[1]['total'], reverse=True)
        
        for naziv, stats in sorted_paketi:
            paket_card = tk.Frame(scrollable_frame, bg=colors['bg'], relief=tk.RIDGE, bd=1)
            paket_card.pack(fill=tk.X, padx=15, pady=8)
            
            tk.Label(paket_card, text=naziv, font=('Segoe UI', 12, 'bold'),
                    bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(10, 5))
            
            stat_text = f"Prodato: {stats['count']}x  |  Zarada: {stats['total']:,.0f} din  |  Prosek: {stats['total']/stats['count']:,.0f} din"
            tk.Label(paket_card, text=stat_text, font=('Segoe UI', 10),
                    bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15, pady=(0, 10))
            
            if ukupna_zarada > 0:
                procenat = (stats['total'] / ukupna_zarada) * 100
                bar_frame = tk.Frame(paket_card, bg=colors['section_bg'], height=25)
                bar_frame.pack(fill=tk.X, padx=15, pady=(0, 10))
                
                bar_fill = tk.Frame(bar_frame, bg='#27ae60', height=25)
                bar_fill.place(relwidth=procenat/100, relheight=1)
                
                tk.Label(bar_frame, text=f"{procenat:.1f}%", font=('Segoe UI', 9, 'bold'),
                        bg=colors['section_bg'], fg=colors['fg']).place(relx=0.5, rely=0.5, anchor='center')
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=(0, 15))
    
    def setup_schedule_tab(self):
        """Setup za Schedule tab - kalendar sa zadacima"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.schedule_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Header
        header_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(header_frame, text="📅 Raspored Zadataka", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=20, pady=15)
        
        # Dodaj dugme za novi zadatak
        button_frame = tk.Frame(content, bg=colors['bg'])
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        add_task_btn = tk.Button(button_frame, text="➕ Dodaj Novi Zadatak", 
                                command=self.dodaj_schedule_zadatak,
                                font=('Segoe UI', 11, 'bold'), bg='#3498db', fg='white',
                                padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_task_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_task_btn, '#3498db', '#5dade2')
        
        # Tabela sa zadacima
        schedule_frame = ttk.Frame(content, style='Main.TFrame')
        schedule_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(schedule_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.schedule_tree = ttk.Treeview(schedule_frame,
                                         columns=('Datum', 'Dan', 'Klijent', 'Zadatak', 'Status'),
                                         height=20, yscrollcommand=scrollbar.set, style=tree_style)
        scrollbar.config(command=self.schedule_tree.yview)
        
        self.schedule_tree.column('#0', width=0, stretch=tk.NO)
        self.schedule_tree.column('Datum', anchor=tk.CENTER, width=100)
        self.schedule_tree.column('Dan', anchor=tk.CENTER, width=100)
        self.schedule_tree.column('Klijent', anchor=tk.W, width=200)
        self.schedule_tree.column('Zadatak', anchor=tk.W, width=300)
        self.schedule_tree.column('Status', anchor=tk.CENTER, width=120)
        
        for col in self.schedule_tree['columns']:
            self.schedule_tree.heading(col, text=col)
        
        self.schedule_tree.pack(fill=tk.BOTH, expand=True)
        self.schedule_tree.bind('<Double-Button-1>', lambda e: self.edit_schedule_zadatak())
        
        # Učitaj zadatke
        self.ucitaj_schedule_zadatke()
    
    def setup_outreach_tab(self):
        """Setup za Outreach tab - praćenje outreach poruka"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        content = tk.Frame(self.outreach_tab, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Header
        header_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(header_frame, text="📧 Outreach Praćenje", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=20, pady=15)
        
        # Dodaj dugme za novi outreach
        button_frame = tk.Frame(content, bg=colors['bg'])
        button_frame.pack(fill=tk.X, pady=(0, 15))
        
        add_outreach_btn = tk.Button(button_frame, text="➕ Dodaj Novi Outreach", 
                                     command=self.dodaj_outreach,
                                     font=('Segoe UI', 11, 'bold'), bg='#e74c3c', fg='white',
                                     padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_outreach_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_outreach_btn, '#e74c3c', '#ec7063')
        
        # Tabela sa outreach-ima
        outreach_frame = ttk.Frame(content, style='Main.TFrame')
        outreach_frame.pack(fill=tk.BOTH, expand=True)
        
        scrollbar = ttk.Scrollbar(outreach_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        tree_style = 'Dark.Treeview' if self.dark_mode else 'Treeview'
        self.outreach_tree = ttk.Treeview(outreach_frame,
                                         columns=('Datum', 'Klijent', 'Email', 'Status', 'Odgovor', 'Napomene'),
                                         height=20, yscrollcommand=scrollbar.set, style=tree_style)
        scrollbar.config(command=self.outreach_tree.yview)
        
        self.outreach_tree.column('#0', width=0, stretch=tk.NO)
        self.outreach_tree.column('Datum', anchor=tk.CENTER, width=100)
        self.outreach_tree.column('Klijent', anchor=tk.W, width=150)
        self.outreach_tree.column('Email', anchor=tk.W, width=200)
        self.outreach_tree.column('Status', anchor=tk.CENTER, width=120)
        self.outreach_tree.column('Odgovor', anchor=tk.CENTER, width=100)
        self.outreach_tree.column('Napomene', anchor=tk.W, width=250)
        
        for col in self.outreach_tree['columns']:
            self.outreach_tree.heading(col, text=col)
        
        self.outreach_tree.pack(fill=tk.BOTH, expand=True)
        self.outreach_tree.bind('<Double-Button-1>', lambda e: self.edit_outreach())
        
        # Učitaj outreach podatke
        self.ucitaj_outreach_podatke()
    
    def darker_color(self, hex_color):
        hex_color = hex_color.lstrip('#')
        return '#' + ''.join([hex(max(0, int(hex_color[i:i+2], 16) - 30))[2:].zfill(2) for i in (0, 2, 4)])
    
    def lighter_color(self, hex_color):
        hex_color = hex_color.lstrip('#')
        return '#' + ''.join([hex(min(255, int(hex_color[i:i+2], 16) + 20))[2:].zfill(2) for i in (0, 2, 4)])
    
    def add_button_hover(self, button, normal_color, hover_color):
        def on_enter(e):
            button['background'] = hover_color
        def on_leave(e):
            button['background'] = normal_color
        button.bind('<Enter>', on_enter)
        button.bind('<Leave>', on_leave)
    
    def fade_in(self, window, alpha=0.0):
        if alpha < 1.0:
            alpha += 0.1
            window.attributes('-alpha', alpha)
            window.after(20, lambda: self.fade_in(window, alpha))
        else:
            window.attributes('-alpha', 1.0)
    
    def show_settings(self):
        """Prikazuje settings dialog"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("⚙️ Podešavanja")
        dialog.geometry("450x450")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="⚙️ Podešavanja", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=25)
        
        # Dark Mode Section
        dark_section = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=1)
        dark_section.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(dark_section, text="🌙 Tamna Tema", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(15, 5))
        
        tk.Label(dark_section, text="Omogući tamnu temu za udobniji rad",
                font=('Segoe UI', 9), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15)
        
        dark_frame = tk.Frame(dark_section, bg=colors['section_bg'])
        dark_frame.pack(anchor=tk.W, padx=15, pady=(10, 15))
        
        def toggle_dark_in_settings():
            self.toggle_dark_mode()
            # Zatvori i ponovo otvori settings da se primeni tema
            dialog.destroy()
            self.show_settings()
        
        dark_mode_btn = tk.Button(dark_frame, 
                                  text="ON" if self.dark_mode else "OFF",
                                  command=toggle_dark_in_settings,
                                  font=('Segoe UI', 10, 'bold'),
                                  bg='#27ae60' if self.dark_mode else '#95a5a6',
                                  fg='white', padx=20, pady=5, border=0,
                                  cursor='hand2', relief=tk.FLAT)
        dark_mode_btn.pack(side=tk.LEFT)
        self.add_button_hover(dark_mode_btn, 
                            '#27ae60' if self.dark_mode else '#95a5a6',
                            '#2ecc71' if self.dark_mode else '#a6b4b6')
        
        # Inactivity Timer Section
        timer_section = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=1)
        timer_section.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(timer_section, text="⏱️ Tajmer Neaktivnosti", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(15, 5))
        
        tk.Label(timer_section, text="Automatska odjava nakon perioda neaktivnosti",
                font=('Segoe UI', 9), bg=colors['section_bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15)
        
        timer_frame = tk.Frame(timer_section, bg=colors['section_bg'])
        timer_frame.pack(anchor=tk.W, padx=15, pady=(10, 15))
        
        tk.Label(timer_frame, text="Minuta:", font=('Segoe UI', 10),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT, padx=(0, 10))
        
        timer_var = tk.IntVar(value=self.inactivity_timeout // 60)
        timer_spinbox = tk.Spinbox(timer_frame, from_=1, to=60, textvariable=timer_var,
                                   font=('Segoe UI', 11), width=8, relief=tk.FLAT, bd=2)
        timer_spinbox.pack(side=tk.LEFT)
        
        def save_settings():
            # Sačuvaj tajmer
            new_timeout = timer_var.get() * 60
            if new_timeout != self.inactivity_timeout:
                self.inactivity_timeout = new_timeout
                self.reset_timer()
            
            messagebox.showinfo("Uspeh", "Podešavanja su uspešno sačuvana!")
            dialog.destroy()
        
        # Save and Close buttons
        btn_frame = tk.Frame(content, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(20, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=save_settings,
                            font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                            padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=(0, 8))
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        close_btn = tk.Button(btn_frame, text="✕ Zatvori", command=dialog.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=30, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.LEFT)
        self.add_button_hover(close_btn, '#95a5a6', '#a6b4b6')
    
    def toggle_dark_mode(self):
        self.dark_mode = not self.dark_mode
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        # Update TTK styles
        self.setup_style()
        
        # Update settings button if it exists
        if hasattr(self, 'dark_mode_setting_btn'):
            self.dark_mode_setting_btn.config(
                text="ON" if self.dark_mode else "OFF",
                bg='#27ae60' if self.dark_mode else '#95a5a6'
            )
            if self.dark_mode:
                self.add_button_hover(self.dark_mode_setting_btn, '#27ae60', '#2ecc71')
            else:
                self.add_button_hover(self.dark_mode_setting_btn, '#95a5a6', '#7f8c8d')
        
        # Update main window
        self.root.configure(bg=colors['bg'])
        
        # Update tree if it exists
        if hasattr(self, 'tree'):
            if self.dark_mode:
                self.tree.configure(style='Dark.Treeview')
            else:
                self.tree.configure(style='Treeview')
        
        # Update frames if they exist
        if hasattr(self, 'main_frame'):
            self.main_frame.configure(style='Main.TFrame')
        if hasattr(self, 'header_frame'):
            self.header_frame.configure(style='Header.TFrame')
    
    def ucitaj_klijente(self, preserve_selection=True):
        # Zapamti trenutno selektovanog klijenta
        selected_id = None
        if preserve_selection:
            selected = self.tree.selection()
            if selected:
                try:
                    selected_id = str(self.tree.item(selected[0])['values'][0]).strip()
                except:
                    pass
        
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Popuni tabelu i zapamti item za ponovno selektovanje
        item_to_select = None
        for id_klijenta in sorted(self.menadzer.klijenti.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            klijent = self.menadzer.klijenti[id_klijenta]
            item = self.tree.insert('', tk.END, text='',
                           values=(id_klijenta, klijent['ime'], klijent['prezime'],
                                 klijent['email'], klijent['telefon'],
                                 len(klijent['paketi']), len(klijent['beleske'])))
            if selected_id and id_klijenta == selected_id:
                item_to_select = item
        
        # Ponovo selektuj klijenta ako je bio selektovan
        if item_to_select:
            self.tree.selection_set(item_to_select)
            self.tree.focus(item_to_select)
            self.tree.see(item_to_select)
    
    def ucitaj_schedule_zadatke(self):
        """Učitava schedule zadatke iz JSON fajla"""
        if not hasattr(self, 'schedule_tree'):
            return
            
        self.schedule_tree.delete(*self.schedule_tree.get_children())
        
        # Učitaj schedule podatke
        schedule_data = self.menadzer.ucitaj_schedule()
        
        for task_id, task in schedule_data.items():
            self.schedule_tree.insert('', tk.END, values=(
                task['datum'],
                task['dan'],
                task['klijent'],
                task['zadatak'],
                task['status']
            ), tags=(task_id,))
    
    def ucitaj_outreach_podatke(self):
        """Učitava outreach podatke iz JSON fajla"""
        if not hasattr(self, 'outreach_tree'):
            return
            
        self.outreach_tree.delete(*self.outreach_tree.get_children())
        
        # Učitaj outreach podatke
        outreach_data = self.menadzer.ucitaj_outreach()
        
        for outreach_id, outreach in outreach_data.items():
            odgovor = "✅" if outreach.get('odgovor', False) else "❌"
            self.outreach_tree.insert('', tk.END, values=(
                outreach['datum'],
                outreach['klijent'],
                outreach['email'],
                outreach['status'],
                odgovor,
                outreach.get('napomene', '')
            ), tags=(outreach_id,))
    
    def dodaj_schedule_zadatak(self):
        """Dijalog za dodavanje novog schedule zadatka"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novi Zadatak")
        dialog.geometry("500x450")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (500 // 2)
        y = (dialog.winfo_screenheight() // 2) - (450 // 2)
        dialog.geometry(f"500x450+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="📅 Novi Zadatak", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        fields = []
        
        # Datum
        tk.Label(content, text="Datum:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        datum_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        datum_entry.pack(fill=tk.X, ipady=8)
        datum_entry.insert(0, datetime.now().strftime('%d.%m.%Y'))
        fields.append(('datum', datum_entry))
        
        # Dan
        tk.Label(content, text="Dan:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        dan_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                            fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        dan_entry.pack(fill=tk.X, ipady=8)
        days = ['Ponedeljak', 'Utorak', 'Sreda', 'Četvrtak', 'Petak', 'Subota', 'Nedelja']
        dan_entry.insert(0, days[datetime.now().weekday()])
        fields.append(('dan', dan_entry))
        
        # Klijent dropdown
        tk.Label(content, text="Klijent:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        klijent_var = tk.StringVar()
        klijenti_lista = [f"{k['ime']} {k['prezime']}" for k in self.menadzer.klijenti.values()]
        
        klijent_combobox = ttk.Combobox(content, textvariable=klijent_var, 
                                       values=klijenti_lista, font=('Segoe UI', 11))
        klijent_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('klijent', klijent_combobox))
        
        # Zadatak
        tk.Label(content, text="Zadatak:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        zadatak_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                                fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        zadatak_entry.pack(fill=tk.X, ipady=8)
        fields.append(('zadatak', zadatak_entry))
        
        # Status dropdown
        tk.Label(content, text="Status:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        status_var = tk.StringVar(value="⏳ Na Čekanju")
        status_combobox = ttk.Combobox(content, textvariable=status_var, 
                                      values=["⏳ Na Čekanju", "🔄 U Toku", "✅ Završeno"],
                                      font=('Segoe UI', 11), state='readonly')
        status_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('status', status_combobox))
        
        # Buttons
        btn_frame = tk.Frame(dialog, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=30, pady=(0, 20))
        
        def sacuvaj():
            data = {}
            for field_name, widget in fields:
                if isinstance(widget, ttk.Combobox):
                    value = widget.get()
                else:
                    value = widget.get()
                    
                if not value and field_name not in ['status']:
                    messagebox.showwarning("Upozorenje", f"Molimo popunite polje: {field_name.capitalize()}")
                    return
                    
                data[field_name] = value
            
            try:
                self.menadzer.dodaj_schedule_zadatak(data)
                self.ucitaj_schedule_zadatke()
                messagebox.showinfo("Uspeh", "Zadatak je uspešno dodat!")
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Došlo je do greške: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="💾 Sačuvaj", command=sacuvaj,
                           font=('Segoe UI', 11, 'bold'), bg='#27ae60', fg='white',
                           padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="❌ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(cancel_btn, '#95a5a6', '#b4bcc2')
    
    def dodaj_outreach(self):
        """Dijalog za dodavanje novog outreach-a"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novi Outreach")
        dialog.geometry("550x550")
        dialog.configure(bg=colors['bg'])
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (550 // 2)
        y = (dialog.winfo_screenheight() // 2) - (550 // 2)
        dialog.geometry(f"550x550+{x}+{y}")
        
        # Header
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        tk.Label(header, text="📧 Novi Outreach", font=('Segoe UI', 14, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(dialog, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=30, pady=20)
        
        fields = []
        
        # Datum
        tk.Label(content, text="Datum:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(10, 5))
        datum_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        datum_entry.pack(fill=tk.X, ipady=8)
        datum_entry.insert(0, datetime.now().strftime('%d.%m.%Y'))
        fields.append(('datum', datum_entry))
        
        # Klijent ime
        tk.Label(content, text="Ime Klijenta:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        klijent_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                                fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        klijent_entry.pack(fill=tk.X, ipady=8)
        fields.append(('klijent', klijent_entry))
        
        # Email
        tk.Label(content, text="Email:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        email_entry = tk.Entry(content, font=('Segoe UI', 11), bg=colors['section_bg'], 
                              fg=colors['fg'], relief=tk.FLAT, insertbackground=colors['fg'])
        email_entry.pack(fill=tk.X, ipady=8)
        fields.append(('email', email_entry))
        
        # Status dropdown
        tk.Label(content, text="Status:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        
        status_var = tk.StringVar(value="📤 Poslato")
        status_combobox = ttk.Combobox(content, textvariable=status_var, 
                                      values=["📤 Poslato", "👀 Viđeno", "💬 Odgovoreno", "❌ Bez Odgovora"],
                                      font=('Segoe UI', 11), state='readonly')
        status_combobox.pack(fill=tk.X, ipady=8)
        fields.append(('status', status_combobox))
        
        # Odgovor checkbox
        odgovor_var = tk.BooleanVar()
        odgovor_check = tk.Checkbutton(content, text="Klijent je odgovorio", variable=odgovor_var,
                                      font=('Segoe UI', 10), bg=colors['bg'], fg=colors['fg'],
                                      selectcolor=colors['section_bg'], activebackground=colors['bg'],
                                      activeforeground=colors['fg'])
        odgovor_check.pack(anchor=tk.W, pady=(15, 5))
        fields.append(('odgovor', odgovor_var))
        
        # Napomene
        tk.Label(content, text="Napomene:", font=('Segoe UI', 10), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, pady=(15, 5))
        napomene_text = tk.Text(content, font=('Segoe UI', 10), bg=colors['section_bg'], 
                               fg=colors['fg'], relief=tk.FLAT, height=5, insertbackground=colors['fg'])
        napomene_text.pack(fill=tk.BOTH, expand=True)
        fields.append(('napomene', napomene_text))
        
        # Buttons
        btn_frame = tk.Frame(dialog, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=30, pady=(10, 20))
        
        def sacuvaj():
            data = {}
            for field_name, widget in fields:
                if isinstance(widget, ttk.Combobox):
                    value = widget.get()
                elif isinstance(widget, tk.BooleanVar):
                    value = widget.get()
                elif isinstance(widget, tk.Text):
                    value = widget.get('1.0', tk.END).strip()
                else:
                    value = widget.get()
                
                if not value and field_name not in ['napomene', 'odgovor']:
                    messagebox.showwarning("Upozorenje", f"Molimo popunite polje: {field_name.capitalize()}")
                    return
                    
                data[field_name] = value
            
            try:
                self.menadzer.dodaj_outreach(data)
                self.ucitaj_outreach_podatke()
                messagebox.showinfo("Uspeh", "Outreach je uspešno dodat!")
                dialog.destroy()
            except Exception as e:
                messagebox.showerror("Greška", f"Došlo je do greške: {str(e)}")
        
        save_btn = tk.Button(btn_frame, text="💾 Sačuvaj", command=sacuvaj,
                           font=('Segoe UI', 11, 'bold'), bg='#e74c3c', fg='white',
                           padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#e74c3c', '#ec7063')
        
        cancel_btn = tk.Button(btn_frame, text="❌ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                              padx=25, pady=10, border=0, cursor='hand2', relief=tk.FLAT)
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(cancel_btn, '#95a5a6', '#b4bcc2')
    
    def edit_schedule_zadatak(self):
        """Izmena selektovanog schedule zadatka"""
        selection = self.schedule_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite zadatak za izmenu.")
            return
        
        # Ovde možeš dodati funkcionalnost za editovanje
        messagebox.showinfo("Info", "Funkcija za izmenu zadatka će uskoro biti dostupna!")
    
    def edit_outreach(self):
        """Izmena selektovanog outreach-a"""
        selection = self.outreach_tree.selection()
        if not selection:
            messagebox.showwarning("Upozorenje", "Molimo odaberite outreach za izmenu.")
            return
        
        # Ovde možeš dodati funkcionalnost za editovanje
        messagebox.showinfo("Info", "Funkcija za izmenu outreach-a će uskoro biti dostupna!")
    
    def pretrazi_klijente(self):
        """Pretražuje klijente po search query"""
        search_query = self.search_var.get().lower().strip()
        
        # Obriši trenutne rezultate
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Ako je search prazan, prikaži sve
        if not search_query:
            self.ucitaj_klijente(preserve_selection=False)
            return
        
        # Filtriraj i prikaži rezultate
        for id_klijenta in sorted(self.menadzer.klijenti.keys(), key=lambda x: int(x) if x.isdigit() else 0):
            klijent = self.menadzer.klijenti[id_klijenta]
            
            # Proveri da li se match nalazi u bilo kom polju
            if (search_query in klijent['ime'].lower() or 
                search_query in klijent['prezime'].lower() or
                search_query in klijent['email'].lower() or
                search_query in klijent['telefon'].lower()):
                
                self.tree.insert('', tk.END, text='',
                               values=(id_klijenta, klijent['ime'], klijent['prezime'],
                                     klijent['email'], klijent['telefon'],
                                     len(klijent['paketi']), len(klijent['beleske'])))
    
    def show_overview(self):
        """Prikazuje overview tab sa statistikama i zaradom"""
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        overview_window = tk.Toplevel(self.root)
        overview_window.title("📊 Pregled Prihoda")
        overview_window.geometry("900x700")
        overview_window.transient(self.root)
        overview_window.attributes('-alpha', 0.0)
        self.fade_in(overview_window)
        overview_window.configure(bg=colors['bg'])
        
        # Header
        header = tk.Frame(overview_window, bg=colors['header'], height=70)
        header.pack(fill=tk.X)
        tk.Label(header, text="📊 Pregled Prihoda Po Paketima", 
                font=('Segoe UI', 18, 'bold'), bg=colors['header'], fg='white').pack(pady=15)
        
        # Content
        content = tk.Frame(overview_window, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Izračunaj statistike
        paket_stats = {}
        ukupno_klijenata = len(self.menadzer.klijenti)
        ukupna_zarada = 0
        
        for klijent in self.menadzer.klijenti.values():
            for paket in klijent['paketi']:
                naziv = paket['naziv']
                cena = float(paket['cena'])
                
                if naziv not in paket_stats:
                    paket_stats[naziv] = {'count': 0, 'total': 0}
                
                paket_stats[naziv]['count'] += 1
                paket_stats[naziv]['total'] += cena
                ukupna_zarada += cena
        
        # Summary section
        summary_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        summary_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(summary_frame, text="💰 Ukupna Statistika", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        stats_grid = tk.Frame(summary_frame, bg=colors['section_bg'])
        stats_grid.pack(fill=tk.X, padx=20, pady=(0, 20))
        
        # Stat boxes
        stat_items = [
            ("👥 Ukupno Klijenata", str(ukupno_klijenata), '#3498db'),
            ("📦 Ukupno Paketa", str(sum(s['count'] for s in paket_stats.values())), '#9b59b6'),
            ("💵 Ukupna Zarada", f"{ukupna_zarada:,.0f} din", '#27ae60')
        ]
        
        for i, (label, value, color) in enumerate(stat_items):
            stat_box = tk.Frame(stats_grid, bg=color, relief=tk.FLAT, bd=0)
            stat_box.grid(row=0, column=i, padx=10, pady=10, sticky='ew')
            stats_grid.columnconfigure(i, weight=1)
            
            tk.Label(stat_box, text=label, font=('Segoe UI', 10), 
                    bg=color, fg='white').pack(pady=(15, 5))
            tk.Label(stat_box, text=value, font=('Segoe UI', 20, 'bold'), 
                    bg=color, fg='white').pack(pady=(0, 15))
        
        # Detalji po paketima
        details_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.RIDGE, bd=2)
        details_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(details_frame, text="📦 Detalji Po Paketima", font=('Segoe UI', 13, 'bold'),
                bg=colors['header'], fg='white').pack(fill=tk.X, padx=15, pady=(15, 10))
        
        # Scrollable frame
        canvas = tk.Canvas(details_frame, bg=colors['section_bg'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(details_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg=colors['section_bg'])
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Sortiraj pakete po zaradi
        sorted_paketi = sorted(paket_stats.items(), key=lambda x: x[1]['total'], reverse=True)
        
        for naziv, stats in sorted_paketi:
            paket_card = tk.Frame(scrollable_frame, bg=colors['bg'], relief=tk.RIDGE, bd=1)
            paket_card.pack(fill=tk.X, padx=15, pady=8)
            
            # Naziv paketa
            tk.Label(paket_card, text=naziv, font=('Segoe UI', 12, 'bold'),
                    bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(10, 5))
            
            # Statistika
            stat_text = f"Prodato: {stats['count']}x  |  Zarada: {stats['total']:,.0f} din  |  Prosek: {stats['total']/stats['count']:,.0f} din"
            tk.Label(paket_card, text=stat_text, font=('Segoe UI', 10),
                    bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=15, pady=(0, 10))
            
            # Progress bar (vizuelni prikaz procenat ukupne zarade)
            if ukupna_zarada > 0:
                procenat = (stats['total'] / ukupna_zarada) * 100
                bar_frame = tk.Frame(paket_card, bg=colors['section_bg'], height=25)
                bar_frame.pack(fill=tk.X, padx=15, pady=(0, 10))
                
                bar_fill = tk.Frame(bar_frame, bg='#27ae60', height=25)
                bar_fill.place(relwidth=procenat/100, relheight=1)
                
                tk.Label(bar_frame, text=f"{procenat:.1f}%", font=('Segoe UI', 9, 'bold'),
                        bg=colors['section_bg'], fg=colors['fg']).place(relx=0.5, rely=0.5, anchor='center')
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=(0, 15))
    
    def dodaj_klijenta_dijalog(self):
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Dodaj Novog Klijenta")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="➕ Dodaj Novog Klijenta", font=('Segoe UI', 16, 'bold'), 
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        fields = [
            ("Ime:", "ime"),
            ("Prezime:", "prezime"),
            ("Email:", "email"),
            ("Telefon:", "telefon")
        ]
        
        entries = {}
        for label_text, field_name in fields:
            label = tk.Label(form_frame, text=label_text, font=('Segoe UI', 10, 'bold'), 
                           bg=colors['bg'], fg=colors['fg'])
            label.pack(anchor=tk.W, pady=(10, 3))
            
            entry_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
            entry = tk.Entry(form_frame, font=('Segoe UI', 10), width=40, 
                           bg=entry_bg, fg=colors['fg'], insertbackground=colors['fg'])
            entry.pack(anchor=tk.W, ipady=8)
            entries[field_name] = entry
        
        entries['ime'].focus()
        
        def sačuvaj():
            ime = entries['ime'].get().strip()
            prezime = entries['prezime'].get().strip()
            email = entries['email'].get().strip()
            telefon = entries['telefon'].get().strip()
            
            if not ime or not prezime or not email:
                messagebox.showerror("Greška", "Molim unesi: Ime, Prezime i Email!")
                return
            
            id_klijenta = self.menadzer.dodaj_klijenta(ime, prezime, email, telefon)
            if id_klijenta:
                messagebox.showinfo("Uspeh", f"✓ Klijent {ime} {prezime} je uspešno dodat!")
                self.ucitaj_klijente()
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Greška pri dodavanju klijenta!")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(30, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def dodeli_paket_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Dodeli Proizvod - {ime} {prezime}")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="📦 Dodeli Proizvod", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        fields = [
            ("Naziv Proizvoda:", "naziv"),
            ("Cena (dinara):", "cena"),
            ("Datum Početka (YYYY-MM-DD):", "datum")
        ]
        
        entries = {}
        for label_text, field_name in fields:
            label = tk.Label(form_frame, text=label_text, font=('Segoe UI', 10, 'bold'), 
                           bg=colors['bg'], fg=colors['fg'])
            label.pack(anchor=tk.W, pady=(10, 3))
            
            entry_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
            entry = tk.Entry(form_frame, font=('Segoe UI', 10), width=40,
                           bg=entry_bg, fg=colors['fg'], insertbackground=colors['fg'])
            entry.pack(anchor=tk.W, ipady=8)
            entries[field_name] = entry
        
        entries['datum'].insert(0, datetime.now().strftime("%Y-%m-%d"))
        entries['naziv'].focus()
        
        def sačuvaj():
            naziv = entries['naziv'].get().strip()
            cena = entries['cena'].get().strip()
            datum = entries['datum'].get().strip()
            
            if not naziv or not cena:
                messagebox.showerror("Greška", "Molim unesi Naziv i Cenu!")
                return
            
            uspeh = self.menadzer.dodeli_paket(id_klijenta, naziv, cena, datum)
            if uspeh:
                messagebox.showinfo("Uspeh", f"✓ Proizvod je uspešno dodeljen!")
                # Osveži tabelu i panel detalja za trenutno selektovanog klijenta
                self.ucitaj_klijente(preserve_selection=True)
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Dodela paketa nije uspela. Pokušaj ponovo.")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(30, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def dodaj_belesku_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Dodaj Belešku - {ime} {prezime}")
        dialog.geometry("500x500")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.resizable(False, False)
        # Fade-in animation
        dialog.attributes('-alpha', 0.0)
        self.fade_in(dialog)
        dialog.configure(bg=colors['bg'])
        
        # Zaglavlje
        header = tk.Frame(dialog, bg=colors['header'], height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="📝 Dodaj Belešku", font=('Segoe UI', 16, 'bold'),
                bg=colors['header'], fg='white').pack(pady=15)
        
        # Forma
        form_frame = tk.Frame(dialog, bg=colors['bg'])
        form_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        label = tk.Label(form_frame, text="Belešku:", font=('Segoe UI', 11, 'bold'), 
                       bg=colors['bg'], fg=colors['fg'])
        label.pack(anchor=tk.W, pady=(0, 5))
        
        text_bg = colors['section_bg'] if not self.dark_mode else '#0f3460'
        beleska_text = tk.Text(form_frame, height=10, width=50, font=('Segoe UI', 10),
                              bg=text_bg, fg=colors['fg'], insertbackground=colors['fg'])
        beleska_text.pack(fill=tk.BOTH, expand=True, ipady=8)
        beleska_text.focus()
        
        def sačuvaj():
            tekst = beleska_text.get("1.0", tk.END).strip()
            
            if not tekst:
                messagebox.showerror("Greška", "Beleška ne može biti prazna!")
                return
            
            uspeh = self.menadzer.dodaj_belesku(id_klijenta, tekst)
            if uspeh:
                messagebox.showinfo("Uspeh", "✓ Beleška je uspešno dodana!")
                # Osveži tabelu i panel detalja za trenutno selektovanog klijenta
                self.ucitaj_klijente(preserve_selection=True)
                dialog.destroy()
            else:
                messagebox.showerror("Greška", "Čuvanje beleške nije uspelo. Pokušaj ponovo.")
        
        # Dugmići
        btn_frame = tk.Frame(form_frame, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, pady=(15, 0))
        
        save_btn = tk.Button(btn_frame, text="✓ Sačuvaj", command=sačuvaj,
                            font=('Segoe UI', 10, 'bold'), bg='#27ae60', fg='white',
                            padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                            activebackground='#229954')
        save_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(save_btn, '#27ae60', '#2ecc71')
        
        cancel_btn = tk.Button(btn_frame, text="✕ Otkaži", command=dialog.destroy,
                              font=('Segoe UI', 10, 'bold'), bg='#e74c3c', fg='white',
                              padx=20, pady=8, border=0, cursor='hand2', relief=tk.FLAT,
                              activebackground='#cb4335')
        cancel_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(cancel_btn, '#e74c3c', '#ec7063')
    
    def obrisi_klijenta_dijalog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        ime = self.tree.item(selected[0])['values'][1]
        prezime = self.tree.item(selected[0])['values'][2]
        
        if messagebox.askyesno("Potvrda", f"Da li želiš da obrišeš:\n\n{ime} {prezime}?"):
            uspeh = self.menadzer.obrisi_klijenta(id_klijenta)
            if uspeh:
                messagebox.showinfo("Uspeh", "✓ Klijent je uspešno obrisan!")
                self.ucitaj_klijente(preserve_selection=False)
            else:
                messagebox.showerror("Greška", "Brisanje klijenta nije uspelo. Pokušaj ponovo.")
    
    def detaljni_pregled(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showerror("Greška", "Molim odaberi klijenta!")
            return
        
        id_klijenta = str(self.tree.item(selected[0])['values'][0]).strip()
        klijent = self.menadzer.klijenti[id_klijenta]
        
        colors = self.dark_colors if self.dark_mode else self.light_colors
        
        detail_window = tk.Toplevel(self.root)
        detail_window.title(f"Detaljni Pregled - {klijent['ime']} {klijent['prezime']}")
        detail_window.geometry("850x750")
        detail_window.transient(self.root)
        # Fade-in animation
        detail_window.attributes('-alpha', 0.0)
        self.fade_in(detail_window)
        detail_window.configure(bg=colors['bg'])
        
        # Zaglavlje sa profilnom karticom
        header = tk.Frame(detail_window, bg=colors['header'], height=120)
        header.pack(fill=tk.X)
        
        header_content = tk.Frame(header, bg=colors['header'])
        header_content.pack(expand=True, fill=tk.BOTH, padx=25, pady=20)
        
        # Avatar/Inicijali
        avatar_frame = tk.Frame(header_content, bg='#27ae60', width=70, height=70)
        avatar_frame.pack(side=tk.LEFT, padx=(0, 20))
        avatar_frame.pack_propagate(False)
        
        inicijali = f"{klijent['ime'][0]}{klijent['prezime'][0]}".upper()
        tk.Label(avatar_frame, text=inicijali, font=('Segoe UI', 24, 'bold'),
                bg='#27ae60', fg='white').place(relx=0.5, rely=0.5, anchor='center')
        
        # Info pored avatara
        info_header = tk.Frame(header_content, bg=colors['header'])
        info_header.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        tk.Label(info_header, text=f"{klijent['ime']} {klijent['prezime']}", 
                font=('Segoe UI', 20, 'bold'), bg=colors['header'], fg='white').pack(anchor=tk.W)
        tk.Label(info_header, text=f"ID: {id_klijenta}", 
                font=('Segoe UI', 10), bg=colors['header'], fg='#95a5a6').pack(anchor=tk.W, pady=(5, 0))
        
        # Sadržaj
        content = tk.Frame(detail_window, bg=colors['bg'])
        content.pack(fill=tk.BOTH, expand=True, padx=25, pady=20)
        
        # Kontakt informacije - moderan dizajn
        contact_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        contact_frame.pack(fill=tk.X, pady=(0, 15))
        
        tk.Label(contact_frame, text="📞 Kontakt Informacije", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(anchor=tk.W, padx=20, pady=(15, 10))
        
        # Grid layout za kontakt info
        contact_grid = tk.Frame(contact_frame, bg=colors['section_bg'])
        contact_grid.pack(fill=tk.X, padx=20, pady=(0, 15))
        
        # Email
        email_box = tk.Frame(contact_grid, bg=colors['bg'], relief=tk.RIDGE, bd=1)
        email_box.grid(row=0, column=0, sticky='ew', padx=(0, 10), pady=5)
        tk.Label(email_box, text="📧 Email", font=('Segoe UI', 9), 
                bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=10, pady=(8, 2))
        tk.Label(email_box, text=klijent['email'], font=('Segoe UI', 11, 'bold'), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=10, pady=(0, 8))
        
        # Telefon
        phone_box = tk.Frame(contact_grid, bg=colors['bg'], relief=tk.RIDGE, bd=1)
        phone_box.grid(row=0, column=1, sticky='ew', padx=(10, 0), pady=5)
        tk.Label(phone_box, text="📱 Telefon", font=('Segoe UI', 9), 
                bg=colors['bg'], fg=colors['fg_secondary']).pack(anchor=tk.W, padx=10, pady=(8, 2))
        tk.Label(phone_box, text=klijent['telefon'], font=('Segoe UI', 11, 'bold'), 
                bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=10, pady=(0, 8))
        
        contact_grid.columnconfigure(0, weight=1)
        contact_grid.columnconfigure(1, weight=1)
        
        # Paketi - modernizovan prikaz
        paketi_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        paketi_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        paketi_header = tk.Frame(paketi_frame, bg=colors['section_bg'])
        paketi_header.pack(fill=tk.X, padx=20, pady=(15, 10))
        
        tk.Label(paketi_header, text="📦 Dodeljeni Paketi", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT)
        
        if klijent['paketi']:
            tk.Label(paketi_header, text=f"{len(klijent['paketi'])} paket(a)", 
                    font=('Segoe UI', 10), bg='#27ae60', fg='white',
                    padx=12, pady=4).pack(side=tk.LEFT, padx=(10, 0))
        
        # Scrollable container za pakete
        paketi_canvas = tk.Canvas(paketi_frame, bg=colors['section_bg'], highlightthickness=0, height=180)
        paketi_scrollbar = ttk.Scrollbar(paketi_frame, orient="vertical", command=paketi_canvas.yview)
        paketi_container = tk.Frame(paketi_canvas, bg=colors['section_bg'])
        
        paketi_container.bind("<Configure>", lambda e: paketi_canvas.configure(scrollregion=paketi_canvas.bbox("all")))
        paketi_canvas.create_window((0, 0), window=paketi_container, anchor="nw")
        paketi_canvas.configure(yscrollcommand=paketi_scrollbar.set)
        
        if klijent['paketi']:
            for i, paket in enumerate(klijent['paketi'], 1):
                paket_card = tk.Frame(paketi_container, bg=colors['bg'], relief=tk.RIDGE, bd=1)
                paket_card.pack(fill=tk.X, padx=20, pady=5)
                
                # Naziv paketa
                tk.Label(paket_card, text=f"{i}. {paket['naziv']}", 
                        font=('Segoe UI', 11, 'bold'), bg=colors['bg'], fg=colors['fg']).pack(anchor=tk.W, padx=15, pady=(10, 5))
                
                # Detalji u grid-u
                details = tk.Frame(paket_card, bg=colors['bg'])
                details.pack(fill=tk.X, padx=15, pady=(0, 10))
                
                tk.Label(details, text=f"💰 {paket['cena']} din", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT, padx=(0, 15))
                tk.Label(details, text=f"📅 {paket['datum_pocetka']}", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT, padx=(0, 15))
                tk.Label(details, text=f"⏰ {paket['datum_dodele']}", font=('Segoe UI', 9),
                        bg=colors['bg'], fg=colors['fg_secondary']).pack(side=tk.LEFT)
        else:
            tk.Label(paketi_container, text="Nema dodeljenih paketa", font=('Segoe UI', 10, 'italic'),
                    bg=colors['section_bg'], fg=colors['fg_secondary']).pack(padx=20, pady=20)
        
        paketi_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        paketi_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Beleške - modernizovan prikaz
        beleske_frame = tk.Frame(content, bg=colors['section_bg'], relief=tk.FLAT, bd=0)
        beleske_frame.pack(fill=tk.BOTH, expand=True)
        
        beleske_header = tk.Frame(beleske_frame, bg=colors['section_bg'])
        beleske_header.pack(fill=tk.X, padx=20, pady=(15, 10))
        
        tk.Label(beleske_header, text="📝 Beleške", font=('Segoe UI', 12, 'bold'),
                bg=colors['section_bg'], fg=colors['fg']).pack(side=tk.LEFT)
        
        if klijent['beleske']:
            tk.Label(beleske_header, text=f"{len(klijent['beleske'])} beleška", 
                    font=('Segoe UI', 10), bg='#f39c12', fg='white',
                    padx=12, pady=4).pack(side=tk.LEFT, padx=(10, 0))
        
        # Scrollable container za beleške
        beleske_canvas = tk.Canvas(beleske_frame, bg=colors['section_bg'], highlightthickness=0, height=180)
        beleske_scrollbar = ttk.Scrollbar(beleske_frame, orient="vertical", command=beleske_canvas.yview)
        beleske_container = tk.Frame(beleske_canvas, bg=colors['section_bg'])
        
        beleske_container.bind("<Configure>", lambda e: beleske_canvas.configure(scrollregion=beleske_canvas.bbox("all")))
        beleske_canvas.create_window((0, 0), window=beleske_container, anchor="nw")
        beleske_canvas.configure(yscrollcommand=beleske_scrollbar.set)
        
        if klijent['beleske']:
            for i, beleska in enumerate(klijent['beleske'], 1):
                beleska_card = tk.Frame(beleske_container, bg=colors['bg'], relief=tk.RIDGE, bd=1)
                beleska_card.pack(fill=tk.X, padx=20, pady=5)
                
                # Header beleške sa datumom
                beleska_header = tk.Frame(beleska_card, bg=colors['header'])
                beleska_header.pack(fill=tk.X)
                
                tk.Label(beleska_header, text=f"Beleška #{i}", font=('Segoe UI', 9, 'bold'),
                        bg=colors['header'], fg='white').pack(side=tk.LEFT, padx=15, pady=8)
                tk.Label(beleska_header, text=beleska['datum'], font=('Segoe UI', 8),
                        bg=colors['header'], fg='#95a5a6').pack(side=tk.RIGHT, padx=15, pady=8)
                
                # Tekst beleške
                tk.Label(beleska_card, text=beleska['tekst'], font=('Segoe UI', 10),
                        bg=colors['bg'], fg=colors['fg'], wraplength=750, justify=tk.LEFT).pack(anchor=tk.W, padx=15, pady=12)
        else:
            tk.Label(beleske_container, text="Nema beleški", font=('Segoe UI', 10, 'italic'),
                    bg=colors['section_bg'], fg=colors['fg_secondary']).pack(padx=20, pady=20)
        
        beleske_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        beleske_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Dodaj dugme za dodavanje beleške
        btn_frame = tk.Frame(detail_window, bg=colors['bg'])
        btn_frame.pack(fill=tk.X, padx=25, pady=(10, 20))
        
        def dodaj_belezku_lokalno():
            detail_window.destroy()
            # Prvo selektuj klijenta u tree-u
            for item in self.tree.get_children():
                if str(self.tree.item(item)['values'][0]).strip() == id_klijenta:
                    self.tree.selection_set(item)
                    self.tree.focus(item)
                    break
            self.dodaj_belesku_dijalog()
        
        add_note_btn = tk.Button(btn_frame, text="📝 Dodaj Novu Belešku", 
                                command=dodaj_belezku_lokalno,
                                font=('Segoe UI', 11, 'bold'), bg='#f39c12', fg='white',
                                padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        add_note_btn.pack(side=tk.LEFT, padx=5)
        self.add_button_hover(add_note_btn, '#f39c12', '#f5b041')
        
        close_btn = tk.Button(btn_frame, text="✖ Zatvori", 
                             command=detail_window.destroy,
                             font=('Segoe UI', 11), bg='#95a5a6', fg='white',
                             padx=25, pady=12, border=0, cursor='hand2', relief=tk.FLAT)
        close_btn.pack(side=tk.RIGHT, padx=5)
        self.add_button_hover(close_btn, '#95a5a6', '#b4bcc2')

if __name__ == "__main__":
    root = tk.Tk()
    app = GUIApp(root)
    root.mainloop()
